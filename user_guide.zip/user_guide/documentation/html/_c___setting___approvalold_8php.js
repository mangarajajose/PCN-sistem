var _c___setting___approvalold_8php =
[
    [ "C_setting_approval_old", "class_c__setting__approval__old.html", "class_c__setting__approval__old" ]
];