var _c___dashboard__new_8php =
[
    [ "C_Dashboard_new", "class_c___dashboard__new.html", "class_c___dashboard__new" ]
];