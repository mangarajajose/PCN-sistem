var _c__setting__approval__new_8php =
[
    [ "C_setting_approval_new", "class_c__setting__approval__new.html", "class_c__setting__approval__new" ]
];