var _c___print__approved_8php =
[
    [ "C_Print_approved", "class_c___print__approved.html", "class_c___print__approved" ]
];