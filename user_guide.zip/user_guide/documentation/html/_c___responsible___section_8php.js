var _c___responsible___section_8php =
[
    [ "C_responsible_section", "class_c__responsible__section.html", "class_c__responsible__section" ]
];