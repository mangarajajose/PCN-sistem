var class_c__email__v2 =
[
    [ "__construct", "class_c__email__v2.html#a095c5d389db211932136b53f25f39685", null ],
    [ "ajax_new_release", "class_c__email__v2.html#ad2fbd9d41860d97f8fecf6f87eac39e3", null ],
    [ "ajax_new_release_pc", "class_c__email__v2.html#a97384bfd8cde789b2a7ea52906683daa", null ],
    [ "ajax_update_approve", "class_c__email__v2.html#ab15ebc9f972e072380f163f0d4d6cca2", null ],
    [ "ajax_update_reject", "class_c__email__v2.html#aaef82badd839af2bda46687a6a562739", null ]
];