var _c__setting__approval_8php =
[
    [ "C_setting_approval", "class_c__setting__approval.html", "class_c__setting__approval" ]
];