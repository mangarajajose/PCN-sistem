var v__print__approved_8php =
[
    [ "$date", "v__print__approved_8php.html#a481c918f8d853749e00b5942cabf599a", null ],
    [ "$date1", "v__print__approved_8php.html#ad1a0fb40498fe029be60f106aaaa7279", null ],
    [ "$newDate", "v__print__approved_8php.html#aa570cff6526d82e488a089370bb344d7", null ],
    [ "$newDate1", "v__print__approved_8php.html#ae55a0a4b0d857915b95abcad08e88450", null ],
    [ "else", "v__print__approved_8php.html#afa4115ba6376baab32f6a807d824cd81", null ],
    [ "if", "v__print__approved_8php.html#a3ab74be7717fb9be442b887c6bfa91e0", null ]
];