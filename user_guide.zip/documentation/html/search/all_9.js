var searchData=
[
  ['load_5ffull_5fcalender_0',['load_full_calender',['../class_c___dashboard__new.html#a28399168c45495c2d6df5f63c04ad189',1,'C_Dashboard_new']]],
  ['login_1',['login',['../class_auth.html#aa311da27ba5706f5710cea7706c8eae1',1,'Auth']]],
  ['logout_2',['logout',['../class_auth.html#a082405d89acd6835c3a7c7a08a7adbab',1,'Auth']]]
];
