var searchData=
[
  ['_24date_0',['$date',['../v__print__approved_8php.html#a481c918f8d853749e00b5942cabf599a',1,'v_print_approved.php']]],
  ['_24date1_1',['$date1',['../v__print__approved_8php.html#ad1a0fb40498fe029be60f106aaaa7279',1,'v_print_approved.php']]],
  ['_24newdate_2',['$newDate',['../v__print__approved_8php.html#aa570cff6526d82e488a089370bb344d7',1,'v_print_approved.php']]],
  ['_24newdate1_3',['$newDate1',['../v__print__approved_8php.html#ae55a0a4b0d857915b95abcad08e88450',1,'v_print_approved.php']]]
];
