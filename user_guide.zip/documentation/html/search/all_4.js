var searchData=
[
  ['delete_5fitemprocess_0',['Delete_itemprocess',['../class_c__display.html#ab1310fe9a6aff648b6b298ad28603949',1,'C_display\Delete_itemprocess()'],['../class_c__displayfullscreen.html#ab1310fe9a6aff648b6b298ad28603949',1,'C_displayfullscreen\Delete_itemprocess()']]],
  ['details_5fitemprocess_1',['Details_itemprocess',['../class_c__display.html#a13cc3f51a6cdd9e9e725e6d566b44200',1,'C_display\Details_itemprocess()'],['../class_c__displayfullscreen.html#a13cc3f51a6cdd9e9e725e6d566b44200',1,'C_displayfullscreen\Details_itemprocess()']]],
  ['details_5fprogress_5fapproved_2',['Details_progress_approved',['../class_c__approver.html#ad716e12a4fecbc0f0714773b25014bd7',1,'C_approver']]],
  ['details_5fuser_3',['Details_User',['../class_c___dashboard.html#af9d5ad4079b76b8cdad8cd9b2205364a',1,'C_Dashboard\Details_User()'],['../class_c___dashboard__new.html#af9d5ad4079b76b8cdad8cd9b2205364a',1,'C_Dashboard_new\Details_User()']]]
];
