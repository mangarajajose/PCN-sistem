var searchData=
[
  ['get_5fuser_5frequest_0',['get_user_request',['../class_auth.html#a7c6969109b88894a3f8d700c6a1943d9',1,'Auth']]],
  ['getpersonaldata_1',['getPersonalData',['../class_c__display.html#a992e3b0d48033139557fdeda295443d0',1,'C_display\getPersonalData()'],['../class_c__displayfullscreen.html#a992e3b0d48033139557fdeda295443d0',1,'C_displayfullscreen\getPersonalData()']]]
];
