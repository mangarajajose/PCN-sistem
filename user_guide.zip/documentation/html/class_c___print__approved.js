var class_c___print__approved =
[
    [ "__construct", "class_c___print__approved.html#a095c5d389db211932136b53f25f39685", null ],
    [ "ajax_approve", "class_c___print__approved.html#ae75ae27344ab12c73d4a079b544bfa79", null ],
    [ "ajax_getbyhdrid", "class_c___print__approved.html#ae02cf083e6cc916d7d546a2fa3706db9", null ],
    [ "ajax_login", "class_c___print__approved.html#a9b9b49f79c546b9f6b0eb6b912595171", null ],
    [ "ajax_reject", "class_c___print__approved.html#ab27c5d1f844d31fbd602fd469dc3f5e6", null ],
    [ "index", "class_c___print__approved.html#a149eb92716c1084a935e04a8d95f7347", null ],
    [ "print_report1", "class_c___print__approved.html#a88f162652253779b4b52aeff91f85ac5", null ],
    [ "print_report2", "class_c___print__approved.html#a58cef09dc9bd51d04c0b457db78f5b89", null ],
    [ "print_report2_approved", "class_c___print__approved.html#ad993a045a61ea1a2de97c21d853dae1d", null ],
    [ "print_show", "class_c___print__approved.html#a1b459c92c810becde46bac5c5449f471", null ],
    [ "print_show2", "class_c___print__approved.html#ae9a3fd0c49b62163843976c4a209afa0", null ]
];