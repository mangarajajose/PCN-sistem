var _c__delegation_8php =
[
    [ "C_delegation", "class_c__delegation.html", "class_c__delegation" ]
];