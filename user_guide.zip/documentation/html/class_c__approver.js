var class_c__approver =
[
    [ "__construct", "class_c__approver.html#a095c5d389db211932136b53f25f39685", null ],
    [ "Details_progress_approved", "class_c__approver.html#ad716e12a4fecbc0f0714773b25014bd7", null ],
    [ "index", "class_c__approver.html#a149eb92716c1084a935e04a8d95f7347", null ]
];