var _c__approval__settlement_8php =
[
    [ "C_approval_settlement", "class_c__approval__settlement.html", "class_c__approval__settlement" ]
];