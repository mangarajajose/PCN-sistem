var _c__effectiveness_8php =
[
    [ "C_effectiveness", "class_c__effectiveness.html", "class_c__effectiveness" ]
];