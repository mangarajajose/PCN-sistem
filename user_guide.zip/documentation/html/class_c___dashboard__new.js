var class_c___dashboard__new =
[
    [ "__construct", "class_c___dashboard__new.html#a095c5d389db211932136b53f25f39685", null ],
    [ "Details_User", "class_c___dashboard__new.html#af9d5ad4079b76b8cdad8cd9b2205364a", null ],
    [ "Index", "class_c___dashboard__new.html#ac36db983080e1b0934908febca5de2d9", null ],
    [ "load_full_calender", "class_c___dashboard__new.html#a28399168c45495c2d6df5f63c04ad189", null ]
];