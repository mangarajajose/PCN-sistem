<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* $config['es_server'] = 'http://172.31.2.37:9200'; */
$config['es_server'] = 'http://10.73.142.62:9200';
/* $config['index'] = 'dbemployee'; */
$config['index'] = 'dbhelpdesk';