Item
Folder Qrcode
Ciqrcode.php
Readme.md

Ref :
https://blog.cacan.id/membuat-qr-code-codeigniter-3/

Langkah :
Setelah itu copy-kan folder qrcode dan file Ciqrcode.php ke direktori ci3-qrcode\application\libraries
Selanjutnya kita siapkan juga folder images pada direktori assets. Folder images akan digunakan untuk menyimpan file image dari QR Code.