<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_global extends CI_Model {
     
}



