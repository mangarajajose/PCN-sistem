<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_ISIR_information extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 **/
     /** ---------------------------------------------- ISIR_information----------------------------------------------**/

       ///@see __construct()
     ///@note fungsi digunakan untuk username masuk web
     ///@attention
     public function __construct(){
        parent::__construct();   

        if ($this->session->userdata('user_name')=="") { /// jika user memasukkan username benar maka login bisa masuk
			redirect('Auth');
		}

        $this->load->helper('date');//untuk mengoneksi ke tanggal masuk login
        $this->load->helper('file'); //untuk mengoneksi ke data       
        $this->load->model('M_ISIR_information');//untuk mengoneksi ke tanggal masuk model PCN LIST
        // $this->load->library('encrypt');    
                  
      }

    ///@see Index()
     ///@note fungsi digunakan untuk select filter dan template
     ///@attention jika select filter tidak sesuai dengan data table maka filter tidak aktif
	public function Index()
	{
        // untuk select filter
        // $data['proses_temporary_and_fullscale'] = $this->M_ISIR_information->tampil_temporary_and_fullscale(); //select filter supplier name
        $data['proses_temporary_and_fullscale'] = ['temporary','fullscale']; //untuk select filter proses temporary dan fullscale
        $data['submital_isir'] = ['1','2','3','4','5','6','7','8','9','10']; //untuk select filter submital isir
        $data['supplier_code'] = ['SUP01','SUP02','SUP03']; //untuk select filter kode supplier
        $data['nama_supplier'] = ['johnny','adit'];//untuk select filter nama supplier
        $data['part_name'] = ['P','N']; //untuk select filter part name
        $data['part_number'] = ['P','N'];//untuk select filter part number
        $data['rohs'] = ['RoHS(Soc)-Cd<01','RoHS(Soc)-HG<01','RoHS(Soc)-Pb<01','RoHS(Soc)-Cr6+<01',];//untuk select filter part rohs 
        $data['product_adapt_to_dds2004'] = ['YES','NO'];//untuk select filter product adapt to dds 2004
        $data['imds_id'] = ['yes','no'];//untuk select filter imds id

        

        // // $data['ISIR_information'] = $this->M_ISIR_information->Tampil_Data();
        $this->load->view('templates/header'); //Tampil header
		$this->load->view('templates/sidebar'); //Tampil Sidebar
		// // $this->load->view('ISIR_information/V_ISIR_information',$data); // Tampil data
        $this->load->view('ISIR_information/V_ISIR_information',$data); // Tampil data
        $this->load->view('templates/footer'); // Tampil footer
               
    }

     ///@see view_data()
     ///@note fungsi digunakan untuk menampilkan data
     ///@attention
     function view_data()
     {
        
        $tables = "tb_ISIR_information";//untuk menampilkan table ISIR ke database
        $search = array('hdrid','isir_category','proses_temporary_and_fullscale','submital_isir','supplier_code','nama_supplier','part_number','part_name','no_tooling','cavity_number','millsheet_submission','rohs','product_adapt_to_dds2004','imds_id'); //untuk menampilkan table ISIR sudah diinput
        
      
        


         // jika memakai IS NULL pada where sql
         $isWhere = null;
         // $isWhere = 'artikel.deleted_at IS NULL';
         header('Content-Type: application/json');
         echo $this->M_ISIR_information->get_tables($tables,$search,$isWhere);//untuk data table pcn controller connect ke model
         
     }
     

   ///@see view_data_where()
    ///@note fungsi digunakan untuk mencari dan menampilkan data 
    ///@attention
    function view_data_where()
    {
        $tables = "tb_ISIR_information";//untuk menampilkan table ISIR ke database
        $search = array('hdrid','isir_category','proses_temporary_and_fullscale','submital_isir','supplier_code','nama_supplier','part_number','part_name','no_tooling','cavity_number','millsheet_submission','rohs','product_adapt_to_dds2004','imds_id'); //untuk menampilkan table ISIR sudah diinput
        
      
        
        // jika memakai IS NULL pada where sql
        if($_POST['searchByFromdate']==''||$_POST['searchByTodate']==''){//Jika sebagai administrator maka akan tampil semua
            $where  = array('transaction_date >'=>'2020-01-01'); //menunjukkan tanggal transaksi             
        }else{
            $where  = array('transaction_date >' => $_POST['searchByFromdate'],'transaction_date <' => $_POST['searchByTodate']);//menunjukkan tanggal transaksi
        };
        
        // jika memakai IS NULL pada where sql
        $isWhere = null;
        // $isWhere = 'artikel.deleted_at IS NULL';
        header('Content-Type: application/json');
        echo $this->M_ISIR_information->get_tables_where($tables,$search,$where,$isWhere);//untuk data table pcn controller connect ke model
        
    }

    //@see view_data_query()
    ///@note fungsi digunakan untuk query data 
    ///@attention 
    function view_data_query()
    {

        $query  = "SELECT kategori.name_kategori AS name_kategori, subkat.* FROM subkat  
                    JOIN kategori ON subkat.id_kategori = kategori.id_kategori"; //untuk query table kategori
        $search = array('name_kategori','subkat','tgl_add');//untuk mencari data table kategori
        $where  = null; //jika data diinput maka kosong


        // $where  = array('name_kategori' => 'Tutorial');
        
        // jika memakai IS NULL pada where sql
        $isWhere = null;
        // $isWhere = 'artikel.deleted_at IS NULL';
        header('Content-Type: application/json');
        echo $this->M_Datatables->get_tables_query($query,$search,$where,$isWhere); //untuk data table pcn controller connect ke model

    }


    //    if($this->session->userdata('authenticated')){ // Jika user sudah login (Session authenticated ditemukan)
    //     }else{
    //     redirect('auth');
    //     }


   ///@see ajax_add()
     ///@note fungsi digunakan untuk menambah data
     ///@attention
    public function ajax_add()
	{

        // ********************* 0. Generate nomor transaksi  *********************          
        $mdate="IR".mdate('%Y%m',time());        //untuk generate tanggal transaksi
        $hdrid2=$this->M_ISIR_information->Max_data($mdate,'tb_ISIR_information')->row();        //untuk code auto increnete bisa diinput
        if ($hdrid2->hdrid==NULL){
            // Jika belum ada
           $hdrid3=$mdate."001";
        }else{
           $hdrid3=$hdrid2->hdrid;
           // Jika sudah ada maka naik 1 level
           $hdrid3="IR".(intval(substr($hdrid3,2,10))+1);
        }
        $hdrid=$hdrid3;
       
        // ********************* 1. Set hdrid  *********************
        $post_data2=array('hdrid'=>$hdrid3);

        // ********************* 2. Transaction date  *********************
        $post_data3=array('transaction_date'=>mdate('%Y-%m-%d',time()));
                
         // ******************** 3. Collect all data post *********************     
        $post_data = $this->input->post();   

        $msg = "success save";
              
        // ********************* 4. Merge data post *********************        
        $post_datamerge=array_merge($post_data,$post_data2,$post_data3);

        // ********************* 5. Simpan data     *********************

        $this->M_ISIR_information->Input_Data($post_datamerge,'tb_ISIR_information');

        // ********************* 6. Upload file jika ada  *********************   
        if(!empty($_FILES['millsheet_submission']['name']))//jika document sudah upload maka document bisa ditampilkan
        {
          $this->upload_file_attach('millsheet_submission',$hdrid,'tb_ISIR_information');//jika upload data dengan attach file sesual file maka data sudah masuk
        }
 
        

       

        $data['status']= $msg; //cek status

        // return value array
        $this->output->set_content_type('application/json')->set_output(json_encode($data));

    }
    
    ///@see ajax_update()
     ///@note fungsi digunakan untuk update data
     ///@attention
    public function ajax_update()
	{

         // ********************* 1. Collect data post *********************
        $post_data = $this->input->post(); //untuk parameter update
        $hdrid=$this->input->post('hdrid');//untuk parameter update tapi number auto increnete tetap tidak berubah
       
        $msg = "success Update"; //jika sudah diupdate maka berhasil

        // **********************  Upload file (filename,hdrid,table)  *********************   
        if(!empty($_FILES['millsheet_submission']['name']))//jika document sudah upload maka document bisa ditampilkan
        {
          $this->upload_file_attach('millsheet_submission',$hdrid,'tb_ISIR_information');//jika upload data dengan attach file sesual file maka data sudah masuk
        }
 
        
                
        // *********************  Merge data All post *********************
        // $post_datamerge=array_merge($post_data,$post_data2);
        $post_datamerge=array_merge($post_data,$post_data);

        // **********************  Simpan data ************************        
        $where = array('hdrid' => $hdrid);//mencari data sudah diupdate        
        $this->M_ISIR_information->Update_Data($where,$post_datamerge,'tb_ISIR_information');//untuk merge data sudah diupdate

        $data['status']="berhasil update";//jika data sudah berhasil diupdate

        // return value array
        $this->output->set_content_type('application/json')->set_output(json_encode($data));

    }


   ///@see ajax_delete()
     ///@note fungsi digunakan untuk delete data
     ///@attention
    public function ajax_delete()
	{

         
        $where = array('hdrid' => $this->input->post('hdrid'));//untuk delete auto increnete
        $this->M_ISIR_information->Delete_Data($where,'tb_ISIR_information');//untuk delete table ISIR_information
        $data['status']="berhasil dihapus";//jika sudah berhasil dihapus maka data akan kosong
        // return value array
        $this->output->set_content_type('application/json')->set_output(json_encode($data));

    }
    
    ///@see ajax_getbyhdrid()
     ///@note fungsi digunakan untuk auto increnete
     ///@attention jika sudah auto increnete maka setiap data ditambah akan bertambah setiap nomor increnete
    function ajax_getbyhdrid(){      

        $hdrid=$this->input->get('hdrid');//untuk auto increnete
        $data=$this->M_ISIR_information->ajax_getbyhdrid($hdrid,'tb_ISIR_information')->row();//untuk request auto increnete
        echo json_encode($data);

    }

    ///@see form_approver_link_mail()
     ///@note fungsi digunakan memberi data ke email
     ///@attention 
    function form_approver_link_mail(){
        
        $id_user_reg=$this->input->get('var1'); //untuk menginput id username variable 1
        $nik=$this->input->get('var2'); //untuk menginput id username variable 2
        
        $data['get_approver']=$this->M_ISIR_information->get_approver($id_user_reg); //untuk request approve
		$data['get_requester']=$this->M_ISIR_information->get_requester($id_user_reg); //untuk request auto increnete
		$data['data']=$this->M_ISIR_information->get_data($id_user_reg); //untuk request nomor pcn
        
        $this->load->view('email/V_ISIR_information',$data); // Tampil data
      
    }


        ///@see upload_file_attach()
    ///@note fungsi attach file bisa diupload
    ///@attention jika path atau ukuran file tidak sesuai function maka attach filenya tidak bisa terisi

    function upload_file_attach($filename,$hdrid,$table){

        if(!empty($_FILES[$filename]['name']))//jika data bisa attach file
        {
          
            $config['upload_path'] = './assets/upload/ISIR_information/';   //path file
            $config['allowed_types'] = 'gif|jpg|png|pdf';      //jenis file   
            $config['overwrite'] = True; //jika file sudah bisa masuk path
            $config['max_size']  = '2000';//maxsimal upload
            $config['max_width']  = '1024'; //maksimal lebar form
            $config['max_height']  = '768'; //maskimal tinggi form
            $config['file_name']=$hdrid.'_'.$filename; //untuk upload attach file
            $this->load->library('upload', $config);//untuk melihat hasil attach file
            $this->upload->initialize($config); //untuk melihat hasil attach file sudah terinput

            if ( ! $this->upload->do_upload($filename)){//untuk mengecek status attach file jika sudah masuk
                // $status = "error";
                 $msg = $this->upload->display_errors(); //jika attach file di upload tidak sesuai maka attac file tidak masuk
            }
            else{
                 $msg = "success upload"; //jika attach file benar maka berhasil upload


                $dataupload = $this->upload->data();
                // $status = "success";
                // $msg = $dataupload['file_name']." berhasil diupload";                    
                $data_update = array($filename =>$dataupload['file_name']);  //data sudah update 
               
                $where = array('hdrid' => $hdrid);  //untuk update auto increnete      
                $this->M_ISIR_information->Update_Data($where,$data_update,$table);

            }

        }

    }

    ///@see import()
     ///@note fungsi digunakan import data
     ///@attention jika file import path file tidak excel maka tidak bisa diimport
    public function import() {

		// $this->form_validation->set_rules('excel', 'File', 'trim|required');

		if ($_FILES['excel']['name'] == '') { //parameter untuk membuat data bisa diimport

			$this->session->set_flashdata('msg', 'File harus diisi'); //jika import file harus terisi
            redirect('C_ISIR_information');

		} else {

			$config['upload_path'] = './assets/excel/'; //untuk path import data
			$config['allowed_types'] = 'xls|xlsx'; //type file import data
			
			$this->load->library('upload', $config); //untuk menampilkan hasil import data
			
			if ( ! $this->upload->do_upload('excel')){ //jika tipe data tidak excel maka akan error
				$error = array('error' => $this->upload->display_errors());
			}
			else{

				$data = $this->upload->data(); //upload import data
				
				error_reporting(E_ALL);
				date_default_timezone_set('Asia/Jakarta'); //menunjukan lokasi daerah jakarta pada web

				include './assets/phpexcel/Classes/PHPExcel/IOFactory.php'; //syntax untuk excel

				$inputFileName = './assets/excel/' .$data['file_name'];//path
        $objPHPExcel = PHPExcel_IOFactory::load($inputFileName); //excel path
				$sheetData = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);

				$index = 0;

				foreach ($sheetData as $key => $value) {

                     // ********************* 0. Generate nomor transaksi  *********************    
                     
                      if ($index > 1 && ucwords($value['C'])!='' ) { //diambil dari baris ke 2

                            // Cari database sekali saja
                            if($index==2){
                                $mdate="IR".mdate('%Y%m',time());        
                                $hdrid2=$this->M_ISIR_information->Max_data($mdate,'tb_ISIR_information')->row();  
                                if ($hdrid2->hdrid==NULL){
                                    // Jika belum ada
                                $hdrid3=$mdate."001";
                                //    $resultData[$index]['hdrid'] =   $hdrid3;
                                }else{
                                    $hdrid3=$hdrid2->hdrid;
                                    // Jika sudah ada maka naik 1 level
                                    $hdrid3="IR".(intval(substr($hdrid3,2,10))+1);
                                    // $resultData[$index]['hdrid'] =   $hdrid3;    
                                }

                            }else{
                                $hdrid3="IR".(intval(substr($hdrid3,2,10))+1);
                            }

                            $resultData[$index]['hdrid'] =   $hdrid3;  
                            $resultData[$index]['transaction_date'] = mdate('%Y-%m-%d',time());    

                        // ---------------------------------- Import Macro Batas sini 1---------------------------------
                        
                            //  Sample
                            $resultData[$index]['vendor_submission'] = ucwords($value['A']);	
                            $resultData[$index]['supplier_name_and_code'] = ucwords($value['A']);	
                            $resultData[$index]['part_number'] = ucwords($value['A']);	
                            $resultData[$index]['assy_for'] = ucwords($value['A']);	
                            $resultData[$index]['part_name'] = ucwords($value['A']);	
                            $resultData[$index]['number_of_ISIR_information'] = ucwords($value['A']);	
                            $resultData[$index]['orderup_or_less_capacity'] = ucwords($value['A']);	
                            $resultData[$index]['cost_down'] = ucwords($value['A']);	
                            $resultData[$index]['quality_problem'] = ucwords($value['A']);	
                            $resultData[$index]['renewal_and_additional'] = ucwords($value['A']);	
                            $resultData[$index]['planning_qty_per_month'] = ucwords($value['A']);	
                            $resultData[$index]['qty'] = ucwords($value['A']);	
                            $resultData[$index]['from_to'] = ucwords($value['A']);	
                            $resultData[$index]['start_delivery'] = ucwords($value['A']);	
                            $resultData[$index]['mold_price'] = ucwords($value['A']);	
                            $resultData[$index]['m_or_c_tonage'] = ucwords($value['A']);	
                            $resultData[$index]['qty_cavity_number'] = ucwords($value['A']);	
                            $resultData[$index]['output_pcs_per_hours'] = ucwords($value['A']);	
                            $resultData[$index]['guarantee_shoot'] = ucwords($value['A']);	
                            $resultData[$index]['total_shoot'] = ucwords($value['A']);	
                            $resultData[$index]['mold_finish'] = ucwords($value['A']);	
                            $resultData[$index]['mold_price_2'] = ucwords($value['A']);	
                            $resultData[$index]['m_or_c_tonage_2'] = ucwords($value['A']);	
                            $resultData[$index]['qty_cavity_number_2'] = ucwords($value['A']);	
                            $resultData[$index]['output_pcs_per_hours_2'] = ucwords($value['A']);	
                            $resultData[$index]['guarantee_shoot_2'] = ucwords($value['A']);	
                            $resultData[$index]['gambar'] = ucwords($value['A']);	
                            $resultData[$index]['total_renewal'] = ucwords($value['A']);	
                            $resultData[$index]['change_core'] = ucwords($value['A']);	
                            $resultData[$index]['change_moving_dies'] = ucwords($value['A']);	
                            $resultData[$index]['change_fixs_dies'] = ucwords($value['A']);	
                            $resultData[$index]['t0_to_t1_trial'] = ucwords($value['A']);	
                            $resultData[$index]['sample_isir_submission'] = ucwords($value['A']);	
                            $resultData[$index]['cycle_time'] = ucwords($value['A']);	
                            $resultData[$index]['cavity'] = ucwords($value['A']);	
                            $resultData[$index]['output_pcs'] = ucwords($value['A']);	
                            $resultData[$index]['total_output_pcs_per_month'] = ucwords($value['A']);	
                            $resultData[$index]['approval_submission_of_renewal_mold'] = ucwords($value['A']);	
                            $resultData[$index]['give_reason_if_it_can_not'] = ucwords($value['A']);	
                            $resultData[$index]['approval_procurement_section'] = ucwords($value['A']);	
                            $resultData[$index]['ISIR_information_no'] = ucwords($value['A']);	
                            $resultData[$index]['ISIR_information_cost'] = ucwords($value['A']);	
                            $resultData[$index]['depresiation_cost'] = ucwords($value['A']);	
                            $resultData[$index]['part_price'] = ucwords($value['A']);	
                            $resultData[$index]['total_cost'] = ucwords($value['A']);	
                            $resultData[$index]['remark_if_any'] = ucwords($value['A']);	
                            $resultData[$index]['approval'] = ucwords($value['A']);	
                            $resultData[$index]['life_shoot_guarantee'] = ucwords($value['A']);	
                            $resultData[$index]['forcast_pc_and_nenkei'] = ucwords($value['A']);	
                            $resultData[$index]['quotation'] = ucwords($value['A']);	
                            
                            

                      }
                       
					$index++;

				}

				unlink('./assets/excel/' .$data['file_name']); //path untuk tampilan import data berupa excel

				if (count($resultData) != 0) {
					$result = $this->M_ISIR_information->insert_batch('tb_ISIR_information',$resultData);
					if ($result > 0) {
						// $this->session->set_flashdata('msg', show_succ_msg('Data Legalitas Perusahaan Berhasil diimport ke database'));
						redirect('C_ISIR_information');
					}
				} else {
                        // $this->session->set_flashdata('msg', show_msg('Data Legalitas Perusahaan Gagal diimport ke database (Data Sudah terupdate)', 'warning', 'fa-warning'));
                        redirect('C_ISIR_information');
				}

			}
		}
	}
    
    /** ---------------------------------------------- /Close controller----------------------------------------------**/

}
