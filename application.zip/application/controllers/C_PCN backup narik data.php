<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">

<!-- Content Header (Page header) -->
<section class="content-header"><!-- untuk kepala judul aplikasi -->
  <div class="container-fluid"><!--untuk jenis container-->
    <div class="row mb-2"><!-- untuk row aplikasi-->
      <div class="col-sm-6"><!--untuk ukuran panjang container-->
        <h1 class="m-0 text-dark">PCN Register</h1><!-- untuk menampilkan judul-->
      </div><!-- /.col -->
      <div class="col-sm-6"><!--untuk ukuran panjang container-->
        <ol class="breadcrumb float-sm-right"><!-- untuk tampilan dashboard aplikasi-->
          <li class="breadcrumb-item"><a href="C_dashboard_new">Dashboard PCN</a></li><!-- judul dashboard-->
          <li class="breadcrumb-item active"><a href="C_dashboard_new">DMIA E-PCN SYSTEM</li><!-- untuk container dashboard-->
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</section>

<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
    
    <!-- <php echo $this->session->flashdata('msg'); ?> -->

    <!-- ##################################### Batas Row 1 #####################################  -->

      <div class="col-12"> <!-- .col -->

        <div class="card"> <!-- .card -->

          <!-- .card-header -->
          <div class="card-header"> <!-- untuk bagian kepala aplikasi -->           
            <div class="row"><!-- untuk row aplikasi-->
               <div class="col-md-12"><!--untuk ukuran panjang container-->
                <div class="card">   <!--untuk class bagian kepala aplikasi-->              
                  <div class="card-header">    <!--untuk jenis bagian kepala aplikasi-->
                  <div id="accordion"><!--untuk menampilkan dan menyembunyikan element HTML-->
                      <!-- we are adding the .class so bootstrap.js collapse plugin detects it -->
                      <div class="card card-primary"> <!--untuk primary kepala aplikasi-->

                        <div class="card-header"><!--untuk jenis bagian kepala aplikasi-->

                          <h4 class="card-title"><!--untuk judul bagian kepala aplikasi-->
                            <?php if ($this->session->userdata('DepartmentAdd')||$this->session->userdata('rolename')=='Administrator Quality'||$this->session->userdata('rolename')=='User Quality') { ?><!--untuk membuat rule hanya user bisa add data-->

                              <a data-toggle="modal" data-target="#modal-default"  Onclick="view_modal('1','Add')" href="#"><!--fungsi add data-->
                              <i class="fa fa-download"></i> Download Data <!--judul add data-->
                              </a>

                            <?php } ?>

                            <?php if ($this->session->userdata('DepartmentAdd')||$this->session->userdata('rolename')=='Administrator Quality'||$this->session->userdata('rolename')=='User Quality') { ?><!--untuk membuat rule hanya user bisa add data-->

                              <a data-toggle="modal" data-target="#modal-import"  href="#"><!--fungsi add data-->
                                <i class="fa fa-upload"></i> Import Data <!--judul add data-->
                              </a>

                            <?php } ?>

                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne"> <!--fungsi custom filler yang digunakan mencari tanggal input-->
                                 <i class="fa fa-binoculars"></i> Custom Filter <!--judul custom filler-->
                            </a>

                            <!-- <a href="<php echo base_url('C_Email/send2')?> "  Onclick='Delete_data()' >
                               <i class="fa fa-plus"></i> Send Mail
                            </a>

                            <button type="button" id="delete" onclick="Send_mail()" class="btn btn-outline-light">Send Mail 2</button>     -->

                          </h4>

                        </div>


                        <div id="collapseOne" class="panel-collapse collapse in"> <!--untuk menampilkan dan menyembunyikan suatu menu--> 
                          <div class="card-body">  <!--untuk body pada kepala aplikasi-->

                              <!-- Date -->
                              <div class="form-group"> <!--untuk fungsi form-->                    

                                <label>Date From:</label> <!--judul date form-->
                                 
                                  <div class="input-group date" data-date-format="YYYY-MM-DD"  id="startdate" data-target-input="nearest"><!--untuk menentukan tanggal pada aplikasi-->
                                      <input type="text" id="search_fromdate" class="form-control datetimepicker-input" data-target="#startdate"/> <!--untuk menentukan mulai tanggal berapa -->
                                      <div class="input-group-append" data-target="#startdate" data-toggle="datetimepicker"><!--untuk menginput tanggal mulai-->
                                          <div class="input-group-text"><i class="fa fa-calendar"></i></div>  <!--fungsi tanggal-->
                                      </div>
                                  </div>

                              </div>

                              <!-- Date To-->
                              <div class="form-group">
                                <label>Date To:</label>
                                  <div class="input-group date" data-date-format="YYYY-MM-DD" id="enddate" data-target-input="nearest"> <!--untuk menentukan tanggal pada aplikasi-->
                                      <input type="text" id="search_todate" class="form-control datetimepicker-input" data-target="#enddate"/> <!--untuk menentukan sampai tanggal berapa -->
                                      <div class="input-group-append" data-target="#enddate" data-toggle="datetimepicker"> <!--untuk sampai tanggal mulai-->
                                          <div class="input-group-text"><i class="fa fa-calendar"></i></div> <!--fungsi tanggal-->
                                      </div>
                                  </div>
                              </div>

                              <button type="button" id="search" class="btn btn-block btn-success" data-toggle="collapse" data-target="#collapseOne">Search</button> <!--fungsi tombol search tanggal dicari-->
                           
                          </div>
                        </div>
                      </div>
                    </div>            
                  </div>
                </div>
                <!-- /.card -->
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->
            <!-- END ACCORDION & CAROUSEL-->                                      
          </div> 
          <!-- /.card-header -->
          
          <div class="card-body">  <!-- .card-body -->

            <table id="example1" class="table table-bordered display nowrap table-striped">
       

              <thead>

              <tr>

                <!-- Th Macro Batas Sini -->
              <th>ACTION</th>
              <th>TRANSACTION ID</th>
              <th>EMAIL</th>
              <th>TRANSACTION_DATE</th>
              <th>SUPPLIER_NAME</th>
              <th>PREPARED</th>
              <th>CHECKED</th>
              <th>APPROVED</th>
              <th>ANY_COST_IMPACT</th>
              <th>COST_IMPACT</th>
              <th>CAPACITY_IMPACT</th>
              <th>BEFORE_CAPACITY</th>
              <th>AFTER_CAPACITY</th>
              <th>PART_NUMBER</th>
              <th>PART_NAME</th>
              <th>PRODUCT_NAME</th>
              <th>OBJECT_TYPE</th>
              <th>REASON_TO_CHANGE</th>
              <th>DESCRIPTION_OF_PROCESS_CHANGE</th>
              <th>CURRENT_PROCESS</th>
              <th>PROPOSED_PROCESS</th>
              <th>CHARACTERISTICS_AFFECTED</th>
              <th>CRITERIA_CRITICAL_ITEM</th>
              <th>TRIAL_MANUFACTURING</th>
              <th>TRIAL_MANUFACTURING_COMPLETED_FINISH</th>
              <th>PROCESS_CAPABILITY_STUDY</th>
              <th>PROCESS_CAPABILITY_STUDY_COMPLETED_FINISH</th>
              <th>INITIAL_SAMPLE_INSPECTION_COMPLETED</th>
              <th>INITIAL_SAMPLE_INSPECTION_COMPLETED_FINISH</th>
              <th>INITIAL_SAMPLE_SUBMISSION</th>
              <th>INITIAL_SAMPLE_SUBMISSION_FINISH</th>
              <th>TIMING_DENSO_APPROVAL</th>
              <th>TIMING_DENSO_APPROVAL_FINISH</th>
              <th>M_OR_P_STARTS</th>
              <th>MASS_PRODUCTION_STARTS_FINISH</th>
              <th>M_OR_P_SHIPMENT</th>
              <th>MASS_PRODUCTION_SHIPMENT_FINISH</th>
              <th>ENTRY_EXAMPLE_START</th>
              <th>ENTRY_EXAMPLE_FINISH</th>
              <th>FOLDER</th>
              <th>STAT</th>

                <!-- /Th Macro Batas Sini -->
                      
              </tr>

              </thead>

              <tbody></tbody>
          
            </table>
                    
          </div> <!-- /.card-body -->
         
        </div> <!-- /.card -->
      </div> <!-- /.col -->

    <!-- ##################################### / Batas Row 1 #####################################  -->
    </div> <!-- /.row -->

  </div><!-- /.container-fluid -->
</section>
<!-- /.content -->    
</div>
<!-- /.content-wrapper -->

<!-- ##################################### Batas Modal #####################################  -->

 <!-- modal-Add / Update -->
 <div class="modal fade" id="modal-default" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">  <!--fungsi add data-->
    <div class="modal-dialog modal-lg" role="document" >  <!--untuk tampilan add data aplikasi-->
        <div class="modal-content">            <!--content add data-->
          <div class="modal-header"> <!--untuk header add data-->
              <h4 class="modal-title" id="exampleModalLabel">DOWNLOAD DATA</h5> <!--judul add data-->
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <!--untuk fungsi tombol close-->
              <span aria-hidden="true">&times;</span>  <!-- jika data ditambah maka data akan muncul--> 
              </button>
          </div>

          <!-- form -->
          <form role="form" id="quickForm">

            <div class="card-body">
  

            <!---------------------------------- Form Macro Batas sini ---------------------------------->
            <div class="card card-primary">
              <div class="card-header">
                <h4 class="card-title">
                  <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwoapproval1">
                    <b> PCN REGISTER </b>
                  </a>
                </h4>
              </div>                  
              <div id="collapseTwoapproval1" class="panel-collapse collapse">
                <div class="card-body">   
                  <br>

<div class="form-group">
   <div class="row">
      <div class="col-md-4">
         <label for="hdrid">PCN NUMBER</label>
      </div>
      <div class="col-md-8">
         <input type="text" name="hdrid" class="form-control" id="hdrid" placeholder="auto generate" readonly>
      </div>
   </div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
        <label>TRANSACTION DATE:</label>
      </div>
      <div class="col-md-4">
        <div class="input-group date" data-date-format="YYYY-MM-DD"  id="timepickertransaction_date" data-target-input="nearest">
          <input type="text" id="transaction_date" name="transaction_date" class="form-control datetimepicker-input" data-target="#timepickertransaction_date"/>
            <div class="input-group-append" data-target="#timepickertransaction_date" data-toggle="datetimepicker">
               <div class="input-group-text"><i class="fa fa-calendar"></i></div>
            </div>
        </div>
      </div>
   </div>
</div>
<div class="form-group">
  <div class="row">
    <div class="col-md-4">
      <label>EMAIL</label>
    </div>
    <div class="col-md-8">
      <select class="form-control select2" id="email" name="email" onchange="handleSelectChange_email(event)" style="width: 100%;">
        <option value='' selected="selected">-Select-</option>
        <?php
          foreach ($email as $value) {
          echo "<option value='$value->email'>$value->email-$value->stat</option>";
          }
        ?>
      </select>
    </div>
  </div>
</div>

<div class="form-group">
<div class="row">
<div class="col-md-4">
  <label>SUPPLIER NAME</label>
</div>
<div class="col-md-8">
  <select class="form-control select2" id="supplier_name" name="supplier_name" onchange="handleSelectChange_supplier_name(event)" style="width: 100%;">
    <option value='' selected="selected">-Select-</option>
    <?php
      foreach ($supplier_name as $value) {
        echo "<option value='$value->supplier_name'> -$value->prepared -$value->check -$value->approved -$value->part_number -$value->part_name -$value->product_name -$value->reason
        -$value->object_type</option>"; //ganti sesuai fild request
      }
    ?>
  </select>
</div>
</div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
         <label for="prepared">PREPARED</label>
      </div>
      <div class="col-md-8">
         <input type="text" name="prepared" class="form-control" id="prepared" >
      </div>
   </div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
         <label for="check">CHECK</label>
      </div>
      <div class="col-md-8">
         <input type="text" name="check" class="form-control" id="check" >
      </div>
   </div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
         <label for="approved">APPROVED</label>
      </div>
      <div class="col-md-8">
         <input type="text" name="approved" class="form-control" id="approved" >
      </div>
   </div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
         <label for="part_number">PART NUMBER</label>
      </div>
      <div class="col-md-8">
         <input type="text" name="part_number" class="form-control" id="part_number" >
      </div>
   </div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
         <label for="part_name">PART NAME</label>
      </div>
      <div class="col-md-8">
         <input type="text" name="part_name" class="form-control" id="part_name" >
      </div>
   </div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
         <label for="product_name">PRODUCT NAME</label>
      </div>
      <div class="col-md-8">
         <input type="text" name="product_name" class="form-control" id="product_name" >
      </div>
   </div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
         <label for="reason_to_change">REASON </label>
      </div>
      <div class="col-md-8">
         <input type="text" name="reason_to_change" class="form-control" id="reason_to_change" >
      </div>
   </div>
</div>
<div class="form-group">
  <div class="row">
    <div class="col-md-4">
      <label>DESCRIPTION OF PROCESS CHANGE</label>
    </div>
    <div class="col-md-8">
      <select class="form-control select2" id="description_of_process_change" name="description_of_process_change" onchange="handleSelectChange_description_of_process_change(event)" style="width: 100%;">
        <option value='' selected="selected">-Select-</option>
        <?php
          foreach ($description_of_process_change as $value) {
          echo "<option value='$value->description_of_process_change'> -$value->current_process -$value->proposed_process -$value->characteristics_affected -$value->trial_manufacturing -$value->trial_manufacturing_completed_finish
          -$value->process_capability_study -$value->process_capability_study_completed_finish -$value->initial_sample_inspection_completed -$value->initial_sample_inspection_completed_finish 
          -$value->initial_sample_submission -$value->initial_sample_submission_finish -$value->timing_denso_approval -$value->timing_denso_approval_finish -$value->m_or_p_starts -$value->mass_production_starts_finish
          -$value->m_or_p_shipment -$value->mass_production_shipment_finish -$value->entry_example_start -$value->entry_example_finish</option>";
          }
        ?>
      </select>
    </div>
  </div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
         <label for="current_process">CURRENT PROCESS</label>
      </div>
      <div class="col-md-8">
         <input type="text" name="current_process" class="form-control" id="current_process" >
      </div>
   </div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
         <label for="proposed_process">PROPOSED PROCESS</label>
      </div>
      <div class="col-md-8">
         <input type="text" name="proposed_process" class="form-control" id="proposed_process" >
      </div>
   </div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
         <label for="characteristics_affected">CHARACTERISTICS AFFECTED</label>
      </div>
      <div class="col-md-8">
         <input type="text" name="characteristics_affected" class="form-control" id="characteristics_affected" >
      </div>
   </div>
</div>


<br>
    </div>
            </div>
            <br>
            <div class="card card-primary">
              <div class="card-header">
                <h4 class="card-title">
                  <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwoapproval2">
                    <b>criteria change process </b>
                  </a>
                </h4>
              </div>                  
              <div id="collapseTwoapproval2" class="panel-collapse collapse">
                <div class="card-body">   
                  <br>
            <div class="form-group">
<hr style="border:1px solid red">
<label>SUPPLIER</label>
<hr style="border:1px solid red">

<div class="form-group" clearfix>
<div class="icheck-primary d-inline">
  <input type="radio" id="supplier" value="supplier" name="object_type">
  <label for="supplier">
      1.1 NEW SUPPLIER
      (never been in denso)
   </label>
</div>
<br>
<div class="icheck-primary d-inline">
  <input type="radio" id="supplier2" value="supplier2" name="object_type">
   <label for="supplier2">
   1.2 NEW SUPPLIER
   (current denso supplier)
   </label>
</div>
<div class="icheck-primary d-inline">
  <input type="radio" id="supplier3" value="supplier3" name="object_type" >
   <label for="supplier3">
   1.3 ADDITIONAL SUPPLIER
   (current denso supplier)
   </label>
</div>
<div class="icheck-primary d-inline">
  <input type="radio" id="supplier4" value="supplier4" name="object_type" >
   <label for="supplier4">
   1.4 CHANGE SUPPLIER
   (current denso supplier)
   </label>
</div>
<div class="icheck-primary d-inline">
  <input type="radio" id="supplier5" value="supplier5" name="object_type" >
   <label for="supplier5">
   1.5 CHANGE PLACE PRODUCTION
   (same denso supplier)
   </label>
</div>
<br>
<div class="icheck-primary d-inline">
  <input type="radio" id="supplier6" value="supplier6" name="object_type" >
   <label for="supplier6">
   1.6 ADDITIONAL SUPPLIER
   </label>
</div>
<br>
<div class="icheck-primary d-inline">
  <input type="radio" id="supplier7" value="supplier7" name="object_type" >
   <label for="supplier7">
   1.7 CHANGE SUB SUPPLIER
   (change route)
   </label>
</div>
</div>

<br>

<hr style="border:1px solid red">
<label>QUALITY IMPROVEMENT</label>
<hr style="border:1px solid red">

<div class="form-group" clearfix>
<div class="icheck-primary d-inline">
  <input type="radio" id="quality_improvement" value="quality_improvement" name="object_type"  >
  <label for="quality_improvement">
      2.1 ADDITIONAL PROCESS
   </label>
</div>
<br>
<div class="icheck-primary d-inline">
  <input type="radio" id="quality_improvement2" value="quality_improvement2" name="object_type" >
   <label for="quality_improvement2">
     2.2  CHANGE PROCESS
   </label>
</div>
</div>
<br>
<hr style="border:1px solid red">
<label>MATERIAL</label>
<hr style="border:1px solid red">
<div class="form-group" clearfix>
<div class="icheck-primary d-inline">
  <input type="radio" id="material" value="material" name="object_type"  >
  <label for="material">
      3.1 CHANGE MATERIAL SPECIFICATION 
   </label>
</div>
<br>
<div class="icheck-primary d-inline">
  <input type="radio" id="material2" value="material2" name="object_type" >
   <label for="material2">
      3.2 CHANGE MATERIAL MAKER
   </label>
</div>
<div class="icheck-primary d-inline">
  <input type="radio" id="material3" value="material3" name="object_type" >
   <label for="material3">
      3.2 CHANGE PLACE PRODUCTION
      (same material maker company)
   </label>
</div>
</div>

<br>
<hr style="border:1px solid red">
<label>TOOLING/MACHINE</label>
<hr style="border:1px solid red">
<div class="form-group" clearfix>
<div class="icheck-primary d-inline">
  <input type="radio" id="tooling_machine" value="tooling_machine" name="object_type"  >
  <label for="tooling_machine">
      4.1 RENEWAL DIES
   </label>
</div>
<br>
<div class="icheck-primary d-inline">
  <input type="radio" id="tooling_machine2" value="tooling_machine2" name="object_type" >
   <label for="tooling_machine2">
      4.2 ADDITIONAL DIES
   </label>
</div>
<br>
<div class="icheck-primary d-inline">
  <input type="radio" id="tooling_machine3" value="tooling_machine3" name="object_type" >
   <label for="tooling_machine3">
      4.3 REACTIVATION DIES reactivation dies
   </label>
</div>
<br>
<div class="icheck-primary d-inline">
  <input type="radio" id="tooling_machine4" value="tooling_machine4" name="object_type" >
   <label for="tooling_machine4">
      4.4 ADDITONAL MACHINE
      (existing machine)
   </label>
</div>
<br>
<div class="icheck-primary d-inline">
  <input type="radio" id="tooling_machine5" value="tooling_machine5" name="object_type" >
   <label for="tooling_machine5">
      4.5 ADDITONAL MACHINE
      (new machine)
   </label>
</div>
<br>
<div class="icheck-primary d-inline">
  <input type="radio" id="tooling_machine6" value="tooling_machine6" name="object_type" >
   <label for="tooling_machine6">
      4.5.1 YOKOTEN MACHINE SPEC
   </label>
</div>
<br>
<div class="icheck-primary d-inline">
  <input type="radio" id="tooling_machine7" value="tooling_machine7" name="object_type" >
   <label for="tooling_machine7">
      4.5.2 NEW MACHINE SPEC
   </label>
</div>
</div>
<br>

<hr style="border:1px solid red">
<label>CRITERIA CRITICAL ITEM</label>
<hr style="border:1px solid red">
<div class="form-group" clearfix>
<div class="row">
  <div class="icheck-primary d-inline">
     <div class="col-md-20">
        <input type="checkbox" name="criteria_critical_item" id="criteria_critical_item" >
        <img src="<?php echo base_url() ?>assets/dist/img/safety.jpg" style="opacity: .8">
        <label for="criteria_critical_item">

        </label>
     </div>
  </div>
</div>
</div>

<div class="form-group" clearfix>
<div class="row">
  <div class="icheck-primary d-inline">
     <div class="col-md-12">
        <input type="checkbox" name="criteria_critical_item" id="criteria_critical_item" >
        <img src="<?php echo base_url() ?>assets/dist/img/environment.jpg" style="opacity: .8">
        <label for="criteria_critical_item">
  
        </label>
     </div>
  </div>
</div>
</div>

<div class="form-group" clearfix>
<div class="row">
  <div class="icheck-primary d-inline">
     <div class="col-md-12">
        <input type="checkbox" name="criteria_critical_item" id="criteria_critical_item" >
        <img src="<?php echo base_url() ?>assets/dist/img/function.jpg" style="opacity: .8">
        <label for="criteria_critical_item">

        </label>
     </div>
  </div>
</div>
</div>


<div class="form-group" clearfix>
<div class="row">
  <div class="icheck-primary d-inline">
     <div class="col-md-12">
        <input type="checkbox" name="criteria_critical_item" id="criteria_critical_item" >
        <img src="<?php echo base_url() ?>assets/dist/img/critical.jpg" style="opacity: .8">
        <label for="criteria_critical_item">

        </label>
     </div>
  </div>
</div>
</div>


<div class="form-group" clearfix>
<div class="row">
  <div class="icheck-primary d-inline">
     <div class="col-md-12">
        <input type="checkbox" name="criteria_critical_item" id="criteria_critical_item" >
        <img src="<?php echo base_url() ?>assets/dist/img/regulation.jpg" style="opacity: .8">
        <label for="criteria_critical_item">

        </label>
     </div>
  </div>
</div>
</div>


<br>
<hr style="border:1px solid red">
<label>CHANGE AFFECTED</label>
<hr style="border:1px solid red">
<div class="form-group">
<div class="row">
<div class="col-md-4">
  <label>is  there any COST IMPACT ?</label>
</div>
<div class="col-md-8">
  <select class="form-control select2" id="any_cost_impact" name="any_cost_impact" onchange="handleSelectChange_any_cost_impact(event)" style="width: 100%;">
    <option value='' selected="selected">-Select-</option>
    <?php
      foreach ($any_cost_impact as $value) {
        echo "<option value='$value->any_cost_impact'>$value->any_cost_impact -$value->cost_impact</option>"; //ganti sesuai fild request
      }
    ?>
  </select>
</div>
</div>
</div>
<div class="form-group">
<div class="row">
  <div class="col-md-4">
     <label for="cost_impact">If yes please mention</label>
  </div>
  <div class="col-md-8">
     <input type="text" name="cost_impact" class="form-control" id="cost_impact" >
  </div>
</div>
</div>

<div class="form-group">
<div class="row">
<div class="col-md-4">
  <label>is  there any capacity impact ?</label>
</div>
<div class="col-md-8">
  <select class="form-control select2" id="capacity_impact" name="capacity_impact" onchange="handleSelectChange_capacity_impact(event)" style="width: 100%;">
    <option value='' selected="selected">-Select-</option>
    <?php
      foreach ($capacity_impact  as $value) {
        echo "<option value='$value->capacity_impact'>$value->capacity_impact -$value->before_capacity -$value->after_capacity</option>"; //ganti sesuai fild request
      }
    ?>
  </select>
</div>
</div>
</div>
<div class="form-group">
<div class="row">
  <div class="col-md-4">
     <label for="before">CAPACITY BEFORE</label>
  </div>
  <div class="col-md-8">
     <input type="text" name="before_capacity" class="form-control" id="before_capacity" >
  </div>
</div>
</div>
<div class="form-group">
<div class="row">
  <div class="col-md-4">
     <label for="after">CAPACITY AFTER</label>
  </div>
  <div class="col-md-8">
     <input type="text" name="after_capacity" class="form-control" id="after_capacity" >
  </div>
</div>
</div>
<br>

</div>
</div>

</div>
<br>
<div class="card card-primary">
              <div class="card-header">
                <h4 class="card-title">
                  <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwoapproval3">
                    <b>Schedule </b>
                  </a>
                </h4>
              </div>                  
              <div id="collapseTwoapproval3" class="panel-collapse collapse">
                <div class="card-body">   
                  <br>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
        <label>TRIAL MANUFACTURING COMPLETED START:</label>
      </div>
      <div class="col-md-4">
        <div class="input-group date" data-date-format="YYYY-MM-DD"  id="timepickertrial_manufacturing_completed_start" data-target-input="nearest">
          <input type="text" id="trial_manufacturing_completed_start" name="trial_manufacturing_completed_start" class="form-control datetimepicker-input" data-target="#timepickertrial_manufacturing_completed_start"/>
            <div class="input-group-append" data-target="#timepickertrial_manufacturing_completed_start" data-toggle="datetimepicker">
               <div class="input-group-text"><i class="fa fa-calendar"></i></div>
            </div>
        </div>
      </div>
   </div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
        <label>TRIAL MANUFACTURING COMPLETED FINISH:</label>
      </div>
      <div class="col-md-4">
        <div class="input-group date" data-date-format="YYYY-MM-DD"  id="timepickertrial_manufacturing_completed_finish" data-target-input="nearest">
          <input type="text" id="trial_manufacturing_completed_finish" name="trial_manufacturing_completed_finish" class="form-control datetimepicker-input" data-target="#timepickertrial_manufacturing_completed_finish"/>
            <div class="input-group-append" data-target="#timepickertrial_manufacturing_completed_finish" data-toggle="datetimepicker">
               <div class="input-group-text"><i class="fa fa-calendar"></i></div>
            </div>
        </div>
      </div>
   </div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
        <label>INITIAL SAMPLE INPECTION COMPLETED START:</label>
      </div>
      <div class="col-md-4">
        <div class="input-group date" data-date-format="YYYY-MM-DD"  id="timepickerinitial_sample_inpection_completed_start" data-target-input="nearest">
          <input type="text" id="initial_sample_inpection_completed_start" name="initial_sample_inpection_completed_start" class="form-control datetimepicker-input" data-target="#timepickerinitial_sample_inpection_completed_start"/>
            <div class="input-group-append" data-target="#timepickerinitial_sample_inpection_completed_start" data-toggle="datetimepicker">
               <div class="input-group-text"><i class="fa fa-calendar"></i></div>
            </div>
        </div>
      </div>
   </div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
        <label>INITIAL SAMPLE INPECTION COMPLETED FINISH:</label>
      </div>
      <div class="col-md-4">
        <div class="input-group date" data-date-format="YYYY-MM-DD"  id="timepickerinitial_sample_inpection_completed_finish" data-target-input="nearest">
          <input type="text" id="initial_sample_inpection_completed_finish" name="initial_sample_inpection_completed_finish" class="form-control datetimepicker-input" data-target="#timepickerinitial_sample_inpection_completed_finish"/>
            <div class="input-group-append" data-target="#timepickerinitial_sample_inpection_completed_finish" data-toggle="datetimepicker">
               <div class="input-group-text"><i class="fa fa-calendar"></i></div>
            </div>
        </div>
      </div>
   </div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
        <label>INITIAL SAMPLE SUBMISSION START:</label>
      </div>
      <div class="col-md-4">
        <div class="input-group date" data-date-format="YYYY-MM-DD"  id="timepickerinitial_sample_submission_start" data-target-input="nearest">
          <input type="text" id="initial_sample_submission_start" name="initial_sample_submission_start" class="form-control datetimepicker-input" data-target="#timepickerinitial_sample_submission_start"/>
            <div class="input-group-append" data-target="#timepickerinitial_sample_submission_start" data-toggle="datetimepicker">
               <div class="input-group-text"><i class="fa fa-calendar"></i></div>
            </div>
        </div>
      </div>
   </div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
        <label>INITIAL SAMPLE SUBMISSION FINISH:</label>
      </div>
      <div class="col-md-4">
        <div class="input-group date" data-date-format="YYYY-MM-DD"  id="timepickerinitial_sample_submission_finish" data-target-input="nearest">
          <input type="text" id="initial_sample_submission_finish" name="initial_sample_submission_finish" class="form-control datetimepicker-input" data-target="#timepickerinitial_sample_submission_finish"/>
            <div class="input-group-append" data-target="#timepickerinitial_sample_submission_finish" data-toggle="datetimepicker">
               <div class="input-group-text"><i class="fa fa-calendar"></i></div>
            </div>
        </div>
      </div>
   </div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
        <label>TIMING DENSO APPROVAL START:</label>
      </div>
      <div class="col-md-4">
        <div class="input-group date" data-date-format="YYYY-MM-DD"  id="timepickertiming_denso_approval_start" data-target-input="nearest">
          <input type="text" id="timing_denso_approval_start" name="timing_denso_approval_start" class="form-control datetimepicker-input" data-target="#timepickertiming_denso_approval_start"/>
            <div class="input-group-append" data-target="#timepickertiming_denso_approval_start" data-toggle="datetimepicker">
               <div class="input-group-text"><i class="fa fa-calendar"></i></div>
            </div>
        </div>
      </div>
   </div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
        <label>TIMING DENSO APPROVAL FINISH:</label>
      </div>
      <div class="col-md-4">
        <div class="input-group date" data-date-format="YYYY-MM-DD"  id="timepickertiming_denso_approval_finish" data-target-input="nearest">
          <input type="text" id="timing_denso_approval_finish" name="timing_denso_approval_finish" class="form-control datetimepicker-input" data-target="#timepickertiming_denso_approval_finish"/>
            <div class="input-group-append" data-target="#timepickertiming_denso_approval_finish" data-toggle="datetimepicker">
               <div class="input-group-text"><i class="fa fa-calendar"></i></div>
            </div>
        </div>
      </div>
   </div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
        <label>MASS PRODUCTIN STARTS START:</label>
      </div>
      <div class="col-md-4">
        <div class="input-group date" data-date-format="YYYY-MM-DD"  id="timepickermass_productin_starts_start" data-target-input="nearest">
          <input type="text" id="mass_productin_starts_start" name="mass_productin_starts_start" class="form-control datetimepicker-input" data-target="#timepickermass_productin_starts_start"/>
            <div class="input-group-append" data-target="#timepickermass_productin_starts_start" data-toggle="datetimepicker">
               <div class="input-group-text"><i class="fa fa-calendar"></i></div>
            </div>
        </div>
      </div>
   </div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
        <label>MASS PRODUCTIN STARTS FINISH:</label>
      </div>
      <div class="col-md-4">
        <div class="input-group date" data-date-format="YYYY-MM-DD"  id="timepickermass_productin_starts_finish" data-target-input="nearest">
          <input type="text" id="mass_productin_starts_finish" name="mass_productin_starts_finish" class="form-control datetimepicker-input" data-target="#timepickermass_productin_starts_finish"/>
            <div class="input-group-append" data-target="#timepickermass_productin_starts_finish" data-toggle="datetimepicker">
               <div class="input-group-text"><i class="fa fa-calendar"></i></div>
            </div>
        </div>
      </div>
   </div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
        <label>ENTRY EXAMPLE START:</label>
      </div>
      <div class="col-md-4">
        <div class="input-group date" data-date-format="YYYY-MM-DD"  id="timepickerentry_example_start" data-target-input="nearest">
          <input type="text" id="entry_example_start" name="entry_example_start" class="form-control datetimepicker-input" data-target="#timepickerentry_example_start"/>
            <div class="input-group-append" data-target="#timepickerentry_example_start" data-toggle="datetimepicker">
               <div class="input-group-text"><i class="fa fa-calendar"></i></div>
            </div>
        </div>
      </div>
   </div>
</div>
<div class="form-group">
   <div class="row">
      <div class="col-md-4">
        <label>ENTRY EXAMPLE FINISH:</label>
      </div>
      <div class="col-md-4">
        <div class="input-group date" data-date-format="YYYY-MM-DD"  id="timepickerentry_example_finish" data-target-input="nearest">
          <input type="text" id="entry_example_finish" name="entry_example_finish" class="form-control datetimepicker-input" data-target="#timepickerentry_example_finish"/>
            <div class="input-group-append" data-target="#timepickerentry_example_finish" data-toggle="datetimepicker">
               <div class="input-group-text"><i class="fa fa-calendar"></i></div>
            </div>
        </div>
      </div>
   </div>
</div>

<br>
            </div>
              </div>
</div>
<br>
    <div class="card card-primary">
              <div class="card-header">
                <h4 class="card-title">
                  <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwoapproval4">
                    <b>Attach Document </b>
                  </a>
                </h4>
              </div>                  
              <div id="collapseTwoapproval4" class="panel-collapse collapse">
                <div class="card-body">   
                  <br>
              <div id="form_supplier" class="form_supplier">
                <div id="form_supplier" class="form_supplier2">
                <div class="form-group" id='1'>
                  <div class="row">
                    <div class="col-md-4">
                      <label for="requirement_document">Detail Of Process Change (6M+EAS)</label>
                    </div>
                    <div class="col-md-1">
                      <a class="btn btn-success" id="requirement_document_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
                    </div>
                    <div class="col-md-7">
                      <div class="custom-file">
                        <input type="file" class="custom-file-input" id="requirement_document" multiple="" name="requirement_document">
                        <label class="custom-file-label" for="requirement_document" id="requirement_document_label">Choose file</label>
                      </div>
                    </div>
                  </div>
                  <br>
          </div>

          <div class="form-group" id='2'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_1">Supplier Inspection Standard</label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_1_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_1" multiple="" name="requirement_document_1">
                  <label class="custom-file-label" for="requirement_document_1" id="requirement_document_1_label">Choose file</label>
                </div>
              </div>
            </div>
          </div>

          <div class="form-group" id='3'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_2">Control Plan/QCPC</label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_2_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_2" multiple="" name="requirement_document_2">
                  <label class="custom-file-label" for="requirement_document_2" id="requirement_document_2_label">Choose file</label>
                </div>
              </div>
            </div>
           
          </div>
         
          <div class="form-group" id='4'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_3">FMEA</label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_3_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_3" multiple="" name="requirement_document_3">
                  <label class="custom-file-label" for="requirement_document_3" id="requirement_document_3_label">Choose file</label>
                </div>
              </div>
            </div>
            <br>
          </div>
          
          <div class="form-group" id='5'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_4">QA Network</label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_4_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_4" multiple="" name="requirement_document_4">
                  <label class="custom-file-label" for="requirement_document_4" id="requirement_document_4_label">Choose file</label>
                </div>
              </div>
            </div>
            
          </div>

          <div class="form-group" id='6'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_5">Initial Proces Capability Study (Cp,Cpk)</label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_5_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_5" multiple="" name="requirement_document_5">
                  <label class="custom-file-label" for="requirement_document_5" id="requirement_document_5_label">Choose file</label>
                </div>
              </div>
            </div>
            <br>
          </div>
          
          <div class="form-group" id='7'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_6">Material Performance Test Results/MiilSheet</label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_6_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_6" multiple="" name="requirement_document_6">
                  <label class="custom-file-label" for="requirement_document_6" id="requirement_document_6_label">Choose file</label>
                </div>
              </div>
            </div>
          </div>

          <div class="form-group" id='8'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_7">Procces Flow Diagram</label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_7_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_7" multiple="" name="requirement_document_7">
                  <label class="custom-file-label" for="requirement_document_7" id="requirement_document_7_label">Choose file</label>
                </div>
              </div>
            </div>
          </div>

          <div class="form-group" id='9'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_8">Dimensional Results (Layout Inspection,n=1)</label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_8_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_8" multiple="" name="requirement_document_8">
                  <label class="custom-file-label" for="requirement_document_8" id="requirement_document_8_label">Choose file</label>
                </div>
              </div>
            </div>
          </div>
          <div class="form-group" id='10'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_9">Part Submission Warrant (PSW)</label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_9_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_9" multiple="" name="requirement_document_9">
                  <label class="custom-file-label" for="requirement_document_9" id="requirement_document_9_label">Choose file</label>
                </div>
              </div>
            </div>
          </div>
          <div class="form-group" id='11'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_10">ISIR + Baloon Drawing (n=3/cavity)</label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_10_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_10" multiple="" name="requirement_document_10">
                  <label class="custom-file-label" for="requirement_document_10" id="requirement_document_10_label">Choose file</label>
                </div>
              </div>
            </div>
          </div>
          <div class="form-group" id='12'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_11">Record Of SOC Compliance With Customer Specific Requiretments</label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_11_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_11" multiple="" name="requirement_document_11">
                  <label class="custom-file-label" for="requirement_document_11" id="requirement_document_11_label">Choose file</label>
                </div>
              </div>
            </div>
          </div>
          <div class="form-group" id='13'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_12"> Proof Of SOC Compliance(10 substance) </label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_12_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_12" multiple="" name="requirement_document_12">
                  <label class="custom-file-label" for="requirement_document_12" id="requirement_document_12_label">Choose file</label>
                </div>
              </div>
            </div>
          </div>
          <div class="form-group" id='14'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_13">IMDS*</label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_13_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_13" multiple="" name="requirement_document_13">
                  <label class="custom-file-label" for="requirement_document_13" id="requirement_document_13_label">Choose file</label>
                </div>
              </div>
            </div>
          </div>
          <div class="form-group" id='15'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_14">Packaging Specification</label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_14_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_14" multiple="" name="requirement_document_14">
                  <label class="custom-file-label" for="requirement_document_14" id="requirement_document_14_label">Choose file</label>
                </div>
              </div>
            </div>
          </div>
          <div class="form-group" id='16'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_15">QC PLAN</label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_15_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_15" multiple="" name="requirement_document_15">
                  <label class="custom-file-label" for="requirement_document_15" id="requirement_document_15_label">Choose file</label>
                </div>
              </div>
            </div>
          </div>
          <div class="form-group" id='17'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_16">Lot Control System</label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_16_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_16" multiple="" name="requirement_document_16">
                  <label class="custom-file-label" for="requirement_document_16" id="requirement_document_16_label">Choose file</label>
                </div>
              </div>
            </div>
          </div>
          <div class="form-group" id='18'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_17">Supply Chain</label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_17_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_17" multiple="" name="requirement_document_17">
                  <label class="custom-file-label" for="requirement_document_17" id="requirement_document_17_label">Choose file</label>
                </div>
              </div>
            </div>
          </div>
          <div class="form-group" id='19'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_18">Sample Part (After ISIR Ok)</label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_18_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_18" multiple="" name="requirement_document_18">
                  <label class="custom-file-label" for="requirement_document_18" id="requirement_document_18_label">Choose file</label>
                </div>
              </div>
            </div>
          </div>
          <div id="form_supplier1" class="form_supplier1">
          <div id="form_supplier1" class="form_supplier2">
          <div class="form-group" id='20'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_19">Company Profile</label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_19_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_19" multiple="" name="requirement_document_19">
                  <label class="custom-file-label" for="requirement_document_19" id="requirement_document_19_label">Choose file</label>
                </div>
              </div>
            </div>
          </div>
          <div class="form-group" id='21'>
            <div class="row">
            <div class="col-md-4">
              <label for="requirement_document_22">Production Layout Factory</label>
            </div>
            <div class="col-md-1">
              <a class="btn btn-success" id="requirement_document_22_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
            </div>
            <div class="col-md-7">
              <div class="custom-file">
                <input type="file" class="custom-file-input" id="requirement_document_22" multiple="" name="requirement_document_22">
                <label class="custom-file-label" for="requirement_document_22" id="requirement_document_22_label">Choose file</label>
              </div>
            </div>
            </div>
           </div>
            <div class="form-group" id='22'>
            <div class="row">
            <div class="col-md-4">
              <label for="requirement_document_23">Capactiy Review</label>
            </div>
            <div class="col-md-1">
              <a class="btn btn-success" id="requirement_document_23_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
            </div>
            <div class="col-md-7">
              <div class="custom-file">
                <input type="file" class="custom-file-input" id="requirement_document_23" multiple="" name="requirement_document_23">
                <label class="custom-file-label" for="requirement_document_23" id="requirement_document_23_label">Choose file</label>
              </div>
            </div>
          </div>
        </div>
        <div class="form-group" id='23'>
          <div class="row">
            <div class="col-md-4">
              <label for="requirement_document_24">Quality System Certification</label>
            </div>
            <div class="col-md-1">
              <a class="btn btn-success" id="requirement_document_24_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
            </div>
            <div class="col-md-7">
              <div class="custom-file">
                <input type="file" class="custom-file-input" id="requirement_document_24" multiple="" name="requirement_document_24">
                <label class="custom-file-label" for="requirement_document_24" id="requirement_document_24_label">Choose file</label>
              </div>
            </div>
          </div>
        </div>

          <div class="form-group" id='24'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_23">Audit Report by DIAT(Spesial Process)</label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_23_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_23" multiple="" name="requirement_document_23">
                  <label class="custom-file-label" for="requirement_document_23" id="requirement_document_23_label">Choose file</label>
                </div>
              </div>
            </div>
          </div>
          <div class="form-group" id='25'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_24">Audit Report by Denso OGC (IF Necesary)</label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_24_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_24" multiple="" name="requirement_document_24">
                  <label class="custom-file-label" for="requirement_document_24" id="requirement_document_24_label">Choose file</label>
                </div>
              </div>
            </div>
          </div>
          <div class="form-group" id='26'>
            <div class="row">
              <div class="col-md-4">
                <label for="requirement_document_25">Kakotora With Prevention</label>
              </div>
              <div class="col-md-1">
                <a class="btn btn-success" id="requirement_document_25_view" target="_blank"> <i class="fa fa-paperclip"></i> </a>
              </div>
              <div class="col-md-7">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="requirement_document_25" multiple="" name="requirement_document_25">
                  <label class="custom-file-label" for="requirement_document_25" id="requirement_document_25_label">Choose file</label>
                </div>
              </div>
            </div>
          </div>
          </div>
          </div>
          <div class="form-group">
   <div class="row">
      <div class="col-md-4">
         <label for="status">STATUS</label>
      </div>
      <div class="col-md-8">
         <input type="text" name="stat" class="form-control" id="stat" >
      </div>
   </div>
</div>


                          </div>
                            </div>
    <!---------------------------------- / Form Macro Batas sini ---------------------------------->

                <!-- Close Card Body -->  
                </div>
                  
                  <div class="card-footer">
                    <button type="submit" class="btn btn-primary" id="btnsubmit">Save To Draft</button>   <!-- button save ke draft--> 
                    <button type="button" class="btn btn-success" id="btnsend" onclick="sendDraft()">Send</button>  <!-- button send-->               
                    <button type="button" class="btn btn-success" id="btnsend2" onclick="sendDraft2()">Save And Send</button>      <!-- button save and send-->           
                    <button type="button" class="btn btn-danger float-right" data-dismiss="modal">Close</button>  <!-- button close--> 
                  </div>
                               
              </form>    
              <!-- /form  -->

            </div> 
            <!-- Close modal-content -->  
        </div>
        <!-- Close modal-dialog -->  
      </div>
      <!-- Close modal-Add / Update -->  
      </div>
              </div>
                
    <!-- modal-delete -->
      <div class="modal fade" id="modal-delete"> <!-- untuk class delete--> 
        <div class="modal-dialog">  <!-- Close Card Body --> 
          <div class="modal-content bg-danger"> <!-- untuk jenis warna button--> 
            <div class="modal-header"> <!-- untuk kepala delete--> 
              <h4 class="modal-title">Danger Modal</h4> <!-- untuk title modal--> 
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <!--button close--> 
                <span aria-hidden="true">&times;</span> <!-- jika data dihapus maka data akan hilang--> 
              </button>
            </div>

            <div class="modal-body"> <!-- untuk body modal--> 
               <label id="iddelete2" hidden> </label>Apakah ingin delete <label id="iddelete"> </label> ?      <!-- judul apa ingin delete-->             
            </div>

            <div class="modal-footer justify-content-between">              <!-- untuk footer modal--> 
              <form action="#" method="post"> <!-- untuk crud delete--> 
                 <button type="button" id="delete" onclick="Delete_data()" class="btn btn-outline-light">Yes</button>     <!--button yes--> 
              </form>     
              <button type="button" class="btn btn-outline-light" data-dismiss="modal">No</button>        <!--button no-->
            </div>

          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal Delete-->

      <!-- modal-import -->
      <div class="modal fade" id="modal-import"> <!-- untuk modal import--> 
        <div class="modal-dialog"> <!-- Close Card Body --> 
          <div class="modal-content"> <!-- untuk modal content--> 
            <div class="modal-header"><!-- untuk modal header--> 
              <h4 class="modal-title">Import Data</h4> <!-- untuk title modal import data--> 
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <!--button close--> 
                <span aria-hidden="true">&times;</span> <!--jika diimport data lalu masuk maka data akan masuk aplikasi--> 
              </button>
            </div>

            <div class="modal-body"> <!-- untuk body modal--> 
               
              <form method="POST" action="<?php echo base_url('C_PCN/import'); ?>" enctype="multipart/form-data">

                  <div class="input-group form-group"><!-- input form group--> 
                    <span class="input-group-addon" id="sizing-addon2"> <!--input group addon--> 
                      <i class="glyphicon glyphicon-file"></i> <!--type file--> 
                    </span>
                    <input type="file" class="form-control" name="excel" aria-describedby="sizing-addon2"> <!--fungsi type file hanya excel--> 
                  </div>

                  <div class="form-group"> <!-- fungsi form group--> 
                    <div class="col-md-12">  <!--untuk ukuran panjang container-->
                        <button type="submit" class="form-control btn btn-primary"> <i class="glyphicon glyphicon-ok"></i>Import Data</button> <!--button import data-->
                    </div>
                  </div>

              </form>
              
            </div>

            <div class="modal-footer justify-content-between">   
              
              <!-- <button type="button" id="delete"  class="btn btn-outline-light">Import</button>     -->               
              <!-- <button type="button" class="btn btn-outline-light" data-dismiss="modal">No</button>  -->                    

            </div>

          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal Delete-->

      

<script type="text/javascript">

  $(document).ready(function () {

    $.validator.setDefaults({
      submitHandler: function () {

        //berhasil( "Form successful submitted!" );
        var status=$('#exampleModalLabel').text();
       
        if (status=="Add Data"){

          // Ajax insert data
           Simpan_data("Add");

        }else if(status=="Edit Data"){

           // Ajax update data
           Simpan_data("Update");

        }else{

          berhasil(status);

        }

      }
    });

    // $('input[type=radio][name=problem_name]').change(function() {
    //         if (this.value == 'problem_category') {
    //             $('#quickForm').rules('remove');
    //         }
    //         else if (this.value == 'external') {
                
    //         }
    //     });

    $('#quickForm').validate({
      rules: {

				// ---------------------------------- Rule input Macro Batas sini 1---------------------------------
        email: {
required: true,
},
transaction_date: {
required: true,
},
supplier_name: {
required: true,
},
prepared: {
required: true,
},
check: {
required: true,
},
approved: {
required: true,
},
any_cost_impact: {
required: true,
},
cost_impact: {
required: true,
},
capacity_impact: {
required: true,
},
before: {
required: true,
},
after: {
required: true,
},
part_number: {
required: true,
},
part_name: {
required: true,
},
product_name: {
required: true,
},
object_type: {
required: true,
},
reason_to_change: {
required: true,
},
description_of_process_change: {
required: true,
},
current_process: {
required: true,
},
proposed_process: {
required: true,
},
characteristics_affected: {
required: true,
},
criteria_critical_item: {
required: true,
},
trial_manufacturing_completed_start: {
required: true,
},
trial_manufacturing_completed_finish: {
required: true,
},
initial_sample_inpection_completed_start: {
required: true,
},
initial_sample_inpection_completed_finish: {
required: true,
},
initial_sample_submission_start: {
required: true,
},
initial_sample_submission_finish: {
required: true,
},
timing_denso_approval_start: {
required: true,
},
timing_denso_approval_finish: {
required: true,
},
mass_productin_starts_start: {
required: true,
},
mass_productin_starts_finish: {
required: true,
},
entry_example_start: {
required: true,
},
entry_example_finish: {
required: true,
},
requirement_document: {
required: true,
},
requirement_document_1: {
required: true,
},
requirement_document_2: {
required: true,
},
requirement_document_3: {
required: true,
},
requirement_document_4: {
required: true,
},
requirement_document_5: {
required: true,
},
requirement_document_6: {
required: true,
},
requirement_document_7: {
required: true,
},
requirement_document_8: {
required: true,
},
requirement_document_9: {
required: true,
},
requirement_document_10: {
required: true,
},
requirement_document_11: {
required: true,
},
requirement_document_12: {
required: true,
},
requirement_document_13: {
required: true,
},
requirement_document_14: {
required: true,
},
requirement_document_15: {
required: true,
},
requirement_document_16: {
required: true,
},
requirement_document_17: {
required: true,
},
requirement_document_18: {
required: true,
},
requirement_document_19: {
required: true,
},
requirement_document_20: {
required: true,
},
requirement_document_21: {
required: true,
},
requirement_document_22: {
required: true,
},
requirement_document_23: {
required: true,
},
requirement_document_24: {
required: true,
},
requirement_document_25: {
required: true,
},
requirement_document_26: {
required: true,
},
requirement_document_27: {
required: true,
},
requirement_document_28: {
required: true,
},
requirement_document_29: {
required: true,
},
stat: {
required: true,
},



        // ---------------------------------- / Rule input Macro Batas sini 1--------------------------------

      },
      messages: {
    
				// ---------------------------------- Rule input Macro Batas sini 2---------------------------------
        email: {
required: "Please Input email",
minlength: 3
},
transaction_date: {
required: "Please Input transaction_date",
minlength: 3
},
supplier_name: {
required: "Please Input supplier_name",
minlength: 3
},
prepared: {
required: "Please Input prepared",
minlength: 3
},
check: {
required: "Please Input check",
minlength: 3
},
approved: {
required: "Please Input approved",
minlength: 3
},
any_cost_impact: {
required: "Please Input any_cost_impact",
minlength: 3
},
cost_impact: {
required: "Please Input cost_impact",
minlength: 3
},
capacity_impact: {
required: "Please Input capacity_impact",
minlength: 3
},
before: {
required: "Please Input before",
minlength: 3
},
after: {
required: "Please Input after",
minlength: 3
},
part_number: {
required: "Please Input part_number",
minlength: 3
},
part_name: {
required: "Please Input part_name",
minlength: 3
},
product_name: {
required: "Please Input product_name",
minlength: 3
},
object_type: {
required: "Please Input object_type",
minlength: 3
},
reason_to_change: {
required: "Please Input reason_to_change",
minlength: 3
},
description_of_process_change: {
required: "Please Input description_of_process_change",
minlength: 3
},
current_process: {
required: "Please Input current_process",
minlength: 3
},
proposed_process: {
required: "Please Input proposed_process",
minlength: 3
},
characteristics_affected: {
required: "Please Input characteristics_affected",
minlength: 3
},
criteria_critical_item: {
required: "Please Input criteria_critical_item",
minlength: 3
},
trial_manufacturing_completed_start: {
required: "Please Input trial_manufacturing_completed_start",
minlength: 3
},
trial_manufacturing_completed_finish: {
required: "Please Input trial_manufacturing_completed_finish",
minlength: 3
},
initial_sample_inpection_completed_start: {
required: "Please Input initial_sample_inpection_completed_start",
minlength: 3
},
initial_sample_inpection_completed_finish: {
required: "Please Input initial_sample_inpection_completed_finish",
minlength: 3
},
initial_sample_submission_start: {
required: "Please Input initial_sample_submission_start",
minlength: 3
},
initial_sample_submission_finish: {
required: "Please Input initial_sample_submission_finish",
minlength: 3
},
timing_denso_approval_start: {
required: "Please Input timing_denso_approval_start",
minlength: 3
},
timing_denso_approval_finish: {
required: "Please Input timing_denso_approval_finish",
minlength: 3
},
mass_productin_starts_start: {
required: "Please Input mass_productin_starts_start",
minlength: 3
},
mass_productin_starts_finish: {
required: "Please Input mass_productin_starts_finish",
minlength: 3
},
entry_example_start: {
required: "Please Input entry_example_start",
minlength: 3
},
entry_example_finish: {
required: "Please Input entry_example_finish",
minlength: 3
},
requirement_document: {
required: "Please Input requirement_document",
minlength: 3
},
requirement_document_1: {
required: "Please Input requirement_document_1",
minlength: 3
},
requirement_document_2: {
required: "Please Input requirement_document_2",
minlength: 3
},
requirement_document_3: {
required: "Please Input requirement_document_3",
minlength: 3
},
requirement_document_4: {
required: "Please Input requirement_document_4",
minlength: 3
},
requirement_document_5: {
required: "Please Input requirement_document_5",
minlength: 3
},
requirement_document_6: {
required: "Please Input requirement_document_6",
minlength: 3
},
requirement_document_7: {
required: "Please Input requirement_document_7",
minlength: 3
},
requirement_document_8: {
required: "Please Input requirement_document_8",
minlength: 3
},
requirement_document_9: {
required: "Please Input requirement_document_9",
minlength: 3
},
requirement_document_10: {
required: "Please Input requirement_document_10",
minlength: 3
},
requirement_document_11: {
required: "Please Input requirement_document_11",
minlength: 3
},
requirement_document_12: {
required: "Please Input requirement_document_12",
minlength: 3
},
requirement_document_13: {
required: "Please Input requirement_document_13",
minlength: 3
},
requirement_document_14: {
required: "Please Input requirement_document_14",
minlength: 3
},
requirement_document_15: {
required: "Please Input requirement_document_15",
minlength: 3
},
requirement_document_16: {
required: "Please Input requirement_document_16",
minlength: 3
},
requirement_document_17: {
required: "Please Input requirement_document_17",
minlength: 3
},
requirement_document_18: {
required: "Please Input requirement_document_18",
minlength: 3
},
requirement_document_19: {
required: "Please Input requirement_document_19",
minlength: 3
},
requirement_document_20: {
required: "Please Input requirement_document_20",
minlength: 3
},
requirement_document_21: {
required: "Please Input requirement_document_21",
minlength: 3
},
requirement_document_22: {
required: "Please Input requirement_document_22",
minlength: 3
},
requirement_document_23: {
required: "Please Input requirement_document_23",
minlength: 3
},
requirement_document_24: {
required: "Please Input requirement_document_24",
minlength: 3
},
requirement_document_25: {
required: "Please Input requirement_document_25",
minlength: 3
},
requirement_document_26: {
required: "Please Input requirement_document_26",
minlength: 3
},
requirement_document_27: {
required: "Please Input requirement_document_27",
minlength: 3
},
requirement_document_28: {
required: "Please Input requirement_document_28",
minlength: 3
},
requirement_document_29: {
required: "Please Input requirement_document_29",
minlength: 3
},
stat: {
required: "Please Input stat",
minlength: 3
},






        // ---------------------------------- / Rule input Macro Batas sini 2--------------------------------

        //rule input data harus terisi semua
      },
      errorElement: 'span', //span untuk true jika data harus terisi semua
      errorPlacement: function (error, element) {
        error.addClass('invalid-feedback');
        element.closest('.form-group').append(error);//untuk jika tidak terisi maka akan error
      },
      highlight: function (element, errorClass, validClass) {
        $(element).addClass('is-invalid'); //invalid function
      },
      unhighlight: function (element, errorClass, validClass) {
        $(element).removeClass('is-invalid'); //invalid function
      }
    });
  });
</script>

<script type="text/javascript">

      ///@see get view modal
     ///@note fungsi digunakan menampilkan data
     ///@attention 
  function view_modal(hdrid1,status){
                             
          if (status=="Add"){
            
            // Default muncul Containment data
            // Default muncul Containment data


            $('#exampleModalLabel').text('Add Data');  // view pada add data
            $('#quickForm')[0].reset(); // reset form  
           

            var someDate0 = new Date(); //variable date
            var numberOfDaysToAdd0 = 0; //variable number of day
            var result0 = someDate0.setDate(someDate0.getDate() + numberOfDaysToAdd0);//variable date
            $('#submission_date').val(new Date(result0).toISOString().slice(0, 10)); //variable issue date

            var someDate0 = new Date(); //variable date
            var numberOfDaysToAdd0 = 0; //variable number of day
            var result0 = someDate0.setDate(someDate0.getDate() + numberOfDaysToAdd0);//variable date
            $('#issue_date').val(new Date(result0).toISOString().slice(0, 10)); //variable issue date


            var someDate = new Date(); //variable date
            var numberOfDaysToAdd = 3; //variable number of day
            var result = someDate.setDate(someDate.getDate() + numberOfDaysToAdd); //variable date
            $('#containment_date').val(new Date(result).toISOString().slice(0, 10));//variable issue date

            var someDate2 = new Date();//variable date
            var numberOfDaysToAdd2 = 14; //variable number of day
            var result2 = someDate2.setDate(someDate2.getDate() + numberOfDaysToAdd2); //variable date
            $('#report_date').val(new Date(result2).toISOString().slice(0, 10));//variable issue date


            $('#btnsubmit').text('Save To Draft'); // name Save
            document.getElementById("btnsubmit").style.visibility = "visible";    // Visible button              
            //Ajax kosongkan data
            document.getElementById("btnsend").style.visibility = "hidden";    // Visible button              
            document.getElementById("btnsend2").style.visibility = "visible";    // Visible button              
            //Ajax kosongkan data

          }else {

            document.getElementById("btnsend").style.visibility = "visible";    // Visible button              
            //Ajax kosongkan data
           
            // Get Hdri ID
            $('#hdrid').val(hdrid1);
            var hdrid=hdrid1;   

            // Ajax isi data
              $.ajax({
              url: "<?php echo base_url('C_PCN/ajax_getbyhdrid')?>",
              method: "get",
              dataType : "JSON",              
              data: {hdrid:hdrid1},
              success: function (data) {

                $('#email').select2().val(data.email).trigger('change');
              $('#transaction_date').val(data.transaction_date);
              $('#supplier_name').select2().val(data.supplier_name).trigger('change');
              $('#prepared').val(data.prepared);
              $('#check').val(data.check);
              $('#approved').val(data.approved);
              $('#any_cost_impact').select2().val(data.any_cost_impact).trigger('change');
              $('#cost_impact').val(data.cost_impact);
              $('#capacity_impact').select2().val(data.capacity_impact).trigger('change');
              $('#before').val(data.before);
              $('#after').val(data.after);
              $('#part_number').val(data.part_number);
              $('#part_name').val(data.part_name);
              $('#product_name').val(data.product_name);
              $('#object_type').val(data.object_type);
              $('#reason_to_change').val(data.reason_to_change);
              $('#description_of_process_change').select2().val(data.description_of_process_change).trigger('change');
              $('#current_process').val(data.current_process);
              $('#proposed_process').val(data.proposed_process);
              $('#characteristics_affected').val(data.characteristics_affected);
              $('#criteria_critical_item').val(data.criteria_critical_item);
              $('#trial_manufacturing_completed_start').val(data.trial_manufacturing_completed_start);
              $('#trial_manufacturing_completed_finish').val(data.trial_manufacturing_completed_finish);
              $('#initial_sample_inpection_completed_start').val(data.initial_sample_inpection_completed_start);
              $('#initial_sample_inpection_completed_finish').val(data.initial_sample_inpection_completed_finish);
              $('#initial_sample_submission_start').val(data.initial_sample_submission_start);
              $('#initial_sample_submission_finish').val(data.initial_sample_submission_finish);
              $('#timing_denso_approval_start').val(data.timing_denso_approval_start);
              $('#timing_denso_approval_finish').val(data.timing_denso_approval_finish);
              $('#mass_productin_starts_start').val(data.mass_productin_starts_start);
              $('#mass_productin_starts_finish').val(data.mass_productin_starts_finish);
              $('#entry_example_start').val(data.entry_example_start);
              $('#entry_example_finish').val(data.entry_example_finish);



                  document.getElementById('requirement_document_label').innerHTML=data.requirement_document;
                  var a = document.getElementById('requirement_document_view');
                  if(!data.requirement_document==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_1_label').innerHTML=data.requirement_document_1;
                  var a = document.getElementById('requirement_document_1_view');
                  if(!data.requirement_document_1==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_1;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_2_label').innerHTML=data.requirement_document_2;
                  var a = document.getElementById('requirement_document_2_view');
                  if(!data.requirement_document_2==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_2;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_3_label').innerHTML=data.requirement_document_3;
                  var a = document.getElementById('requirement_document_3_view');
                  if(!data.requirement_document_3==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_3;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_4_label').innerHTML=data.requirement_document_4;
                  var a = document.getElementById('requirement_document_4_view');
                  if(!data.requirement_document_4==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_4;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_5_label').innerHTML=data.requirement_document_5;
                  var a = document.getElementById('requirement_document_5_view');
                  if(!data.requirement_document_5==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_5;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_6_label').innerHTML=data.requirement_document_6;
                  var a = document.getElementById('requirement_document_6_view');
                  if(!data.requirement_document_6==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_6;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_7_label').innerHTML=data.requirement_document_7;
                  var a = document.getElementById('requirement_document_7_view');
                  if(!data.requirement_document_7==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_7;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_8_label').innerHTML=data.requirement_document_8;
                  var a = document.getElementById('requirement_document_8_view');
                  if(!data.requirement_document_8==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_8;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_9_label').innerHTML=data.requirement_document_9;
                  var a = document.getElementById('requirement_document_9_view');
                  if(!data.requirement_document_9==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_9;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_10_label').innerHTML=data.requirement_document_10;
                  var a = document.getElementById('requirement_document_10_view');
                  if(!data.requirement_document_10==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_10;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_11_label').innerHTML=data.requirement_document_11;
                  var a = document.getElementById('requirement_document_11_view');
                  if(!data.requirement_document_11==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_11;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_12_label').innerHTML=data.requirement_document_12;
                  var a = document.getElementById('requirement_document_12_view');
                  if(!data.requirement_document_12==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_12;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_13_label').innerHTML=data.requirement_document_13;
                  var a = document.getElementById('requirement_document_13_view');
                  if(!data.requirement_document_13==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_13;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_14_label').innerHTML=data.requirement_document_14;
                  var a = document.getElementById('requirement_document_14_view');
                  if(!data.requirement_document_14==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_14;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_15_label').innerHTML=data.requirement_document_15;
                  var a = document.getElementById('requirement_document_15_view');
                  if(!data.requirement_document_15==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_15;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_16_label').innerHTML=data.requirement_document_16;
                  var a = document.getElementById('requirement_document_16_view');
                  if(!data.requirement_document_16==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_16;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_17_label').innerHTML=data.requirement_document_17;
                  var a = document.getElementById('requirement_document_17_view');
                  if(!data.requirement_document_17==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_17;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_18_label').innerHTML=data.requirement_document_18;
                  var a = document.getElementById('requirement_document_18_view');
                  if(!data.requirement_document_18==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_18;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_19_label').innerHTML=data.requirement_document_19;
                  var a = document.getElementById('requirement_document_19_view');
                  if(!data.requirement_document_19==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_19;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_20_label').innerHTML=data.requirement_document_20;
                  var a = document.getElementById('requirement_document_20_view');
                  if(!data.requirement_document_20==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_20;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_21_label').innerHTML=data.requirement_document_21;
                  var a = document.getElementById('requirement_document_21_view');
                  if(!data.requirement_document_21==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_21;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_22_label').innerHTML=data.requirement_document_22;
                  var a = document.getElementById('requirement_document_22_view');
                  if(!data.requirement_document_22==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_22;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_23_label').innerHTML=data.requirement_document_23;
                  var a = document.getElementById('requirement_document_23_view');
                  if(!data.requirement_document_23==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_23;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_24_label').innerHTML=data.requirement_document_24;
                  var a = document.getElementById('requirement_document_24_view');
                  if(!data.requirement_document_24==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_24;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_25_label').innerHTML=data.requirement_document_25;
                  var a = document.getElementById('requirement_document_25_view');
                  if(!data.requirement_document_25==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_25;
                  }else{
                    a.removeAttribute("href");
                  };
                  $('#status').val(data.status);
                  document.getElementById('requirement_document_26_label').innerHTML=data.requirement_document_26;
                  var a = document.getElementById('requirement_document_26_view');
                  if(!data.requirement_document_26==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_26;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_27_label').innerHTML=data.requirement_document_27;
                  var a = document.getElementById('requirement_document_27_view');
                  if(!data.requirement_document_27==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_27;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_28_label').innerHTML=data.requirement_document_28;
                  var a = document.getElementById('requirement_document_28_view');
                  if(!data.requirement_document_28==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_28;
                  }else{
                    a.removeAttribute("href");
                  };
                  document.getElementById('requirement_document_29_label').innerHTML=data.requirement_document_29;
                  var a = document.getElementById('requirement_document_29_view');
                  if(!data.requirement_document_29==''){
                    a.href = "<?php echo base_url('assets/upload/PCN') ?>" + data.requirement_document_29;
                  }else{
                    a.removeAttribute("href");
                  };
                  $('#stat').val(data.stat);





                // ---------------------------------- / Data val Macro  Batas sini ------------------------------
                                                           
                                                             
                },
              error: function (e) {
                      alert(e);
                     
                  }
            });
            
            // Disable and button submit dan text form           
            if(status=="View"){
              document.getElementById("btnsubmit").style.visibility = "hidden";   //fungsi hidden tombol submit
              document.getElementById("btnsend").style.visibility = "hidden";   //fungsi hidden tombol save dan send
              document.getElementById("btnsend2").style.visibility = "hidden";  //fungsi hidden tombol send
              $('#exampleModalLabel').text('View Data'); //name view              
            }else{
              $('#exampleModalLabel').text('Edit Data'); //name view 
              $('#btnsubmit').text('Update'); //name Update  
              document.getElementById("btnsend2").style.visibility = "hidden"; //fungsi hidden tombol send
              document.getElementById("btnsubmit").style.visibility = "visible";  //fungsi visible tombol submit
            }
          
          }

        
         //untuk hidden supplier data jika klik supplier maka akan muncul beberapa attach file saja
        $('input[type=radio][name=supplier').change(function() {
          if(this.value == 'supplier'){
          }else if(this.value =='supplier2'){//jika dipilih supplier akan menonaktikan beberapa attach file
            $("#20").css('display','none'); //beberapa attach file hidden
            $("#21").css('display','none');
            $("#23").css('display','none');
            $("#24").css('display','none');
          }else if(this.value =='supplier3'){//jika dipilih supplier akan menonaktikan beberapa attach file
            $("#20").css('display','none');//beberapa attach file hidden
            $("#21").css('display','none');
            $("#23").css('display','none');
            $("#24").css('display','none');
          }else if(this.value =='supplier4'){//jika dipilih supplier akan menonaktikan beberapa attach file
            $("#20").css('display','none');//beberapa attach file hidden
            $("#21").css('display','none');
            $("#23").css('display','none');
            $("#24").css('display','none');
          }else if(this.value =='supplier5'){//jika dipilih supplier akan menonaktikan beberapa attach file
            $("#7").css('display','none');//beberapa attach file hidden
            $("#8").css('display','none');
            $("#9").css('display','none');
            $("#10").css('display','none');
            $("#12").css('display','none');
            $("#13").css('display','none');
            $("#14").css('display','none');
            $("#15").css('display','none');
            $("#16").css('display','none');
            $("#17").css('display','none');
            $("#20").css('display','none');
            $("#21").css('display','none');
            $("#23").css('display','none');
            $("#24").css('display','none');
            $("#25").css('display','none');
          }else if(this.value =='supplier6'){//jika dipilih supplier akan menonaktikan beberapa attach file
            $("#7").css('display','none');//beberapa attach file hidden
            $("#8").css('display','none');
            $("#9").css('display','none');
            $("#10").css('display','none');
            $("#12").css('display','none');
            $("#13").css('display','none');
            $("#14").css('display','none');
            $("#15").css('display','none');
            $("#16").css('display','none');
            $("#17").css('display','none');
            $("#20").css('display','none');
            $("#21").css('display','none');
            $("#23").css('display','none');
            $("#24").css('display','none');
            $("#25").css('display','none');
          }else if(this.value =='supplier7'){//jika dipilih supplier akan menonaktikan beberapa attach file
            $("#7").css('display','none');//beberapa attach file hidden
            $("#8").css('display','none');
            $("#9").css('display','none');
            $("#10").css('display','none');
            $("#12").css('display','none');
            $("#13").css('display','none');
            $("#14").css('display','none');
            $("#15").css('display','none');
            $("#16").css('display','none');
            $("#17").css('display','none');
            $("#20").css('display','none');
            $("#21").css('display','none');
            $("#23").css('display','none');
            $("#24").css('display','none');
            $("#25").css('display','none');
          }else{
            $("#supplier").removeAttr("checked"); //untuk check apakah sudah hidden
            $("#supplier2").css('display','block');//untuk blok attach file sudah dihidden
            }
          });

 //untuk hidden materia data jika klik material maka akan muncul beberapa attach file saja
        $('input[type=radio][name=material]').change(function() {
          if(this.value == 'material'){ //jika dipilih material akan menonaktikan beberapa attach file
            $("#15").css('display','none');//beberapa attach file hidden
            $("#16").css('display','none');
            $("#17").css('display','none');
            $("#20").css('display','none');
            $("#21").css('display','none');
            $("#22").css('display','none');
            $("#23").css('display','none');
            $("#24").css('display','none');
            $("#25").css('display','none');       
          }else if(this.value =='material2'){ //jika dipilih material2 akan menonaktikan beberapa attach file
            $("#15").css('display','none');//beberapa attach file hidden
            $("#16").css('display','none');
            $("#17").css('display','none');
            $("#20").css('display','none');
            $("#21").css('display','none');
            $("#22").css('display','none');
            $("#23").css('display','none');
            $("#24").css('display','none');
            $("#25").css('display','none');
          }else if(this.value =='material3'){ //jika dipilih material3 akan menonaktikan beberapa attach file
            $("#15").css('display','none');//beberapa attach file hidden
            $("#16").css('display','none');
            $("#17").css('display','none');
            $("#20").css('display','none');
            $("#21").css('display','none');
            $("#22").css('display','none');
            $("#23").css('display','none');
            $("#24").css('display','none');
            $("#25").css('display','none');
          }else{
            $("#material").removeAttr("checked");//untuk check apakah sudah hidden
            $("#material2").css('display','block');//untuk blok attach file sudah dihidden
            }
        });

         //untuk hidden quality improvement data jika klik quality improvement maka akan muncul beberapa attach file saja
        $('input[type=radio][name=quality_improvement').change(function() {
          if(this.value == 'quality_improvement'){;//jika dipilih quality improvement akan menonaktikan beberapa attach file
            $("#5").css('display','none');//beberapa attach file hidden
            $("#7").css('display','none');
            $("#8").css('display','none');
            $("#9").css('display','none');
            $("#10").css('display','none');
            $("#12").css('display','none');
            $("#13").css('display','none');
            $("#14").css('display','none');
            $("#15").css('display','none');
            $("#16").css('display','none');
            $("#17").css('display','none');
            $("#19").css('display','none');
            $("#20").css('display','none');
            $("#21").css('display','none');
            $("#22").css('display','none');
            $("#24").css('display','none');
            $("#25").css('display','none');
          }else if(this.value =='quality_improvement2'){//jika dipilih quality improvement 2 akan menonaktikan beberapa attach file
            $("#5").css('display','none');//beberapa attach file hidden
            $("#7").css('display','none');
            $("#8").css('display','none');
            $("#9").css('display','none');
            $("#10").css('display','none');
            $("#12").css('display','none');
            $("#13").css('display','none');
            $("#14").css('display','none');
            $("#15").css('display','none');
            $("#16").css('display','none');
            $("#17").css('display','none');
            $("#19").css('display','none');
            $("#20").css('display','none');
            $("#21").css('display','none');
            $("#22").css('display','none');
            $("#24").css('display','none');
            $("#25").css('display','none');
          }else{
            $("#quality_improvement").removeAttr("checked");//untuk check apakah sudah hidden
            $("#quality_improvement2").css('display','block');//untuk blok attach file sudah dihidden
            }
          });

          //untuk hidden tooling machine improvement data jika klik tooling machine improvement maka akan muncul beberapa attach file saja
          $('input[type=radio][name=tooling_machine').change(function() {
          if(this.value == 'tooling_machine'){; //jika dipilih tooling machine akan menonaktikan beberapa attach file
            $("#3").css('display','none');//beberapa attach file hidden
            $("#4").css('display','none');
            $("#5").css('display','none');
            $("#6").css('display','none');
            $("#7").css('display','none');
            $("#8").css('display','none');
            $("#9").css('display','none');
            $("#10").css('display','none');
            $("#12").css('display','none');
            $("#13").css('display','none');
            $("#14").css('display','none');
            $("#15").css('display','none');
            $("#16").css('display','none');
            $("#17").css('display','none');
            $("#18").css('display','none');
            $("#24").css('display','none');
            $("#25").css('display','none');
            $("#26").css('display','none');
          }else if(this.value =='tooling_machine2'){//jika dipilih tooling machine 2 akan menonaktikan beberapa attach file
            $("#3").css('display','none');//beberapa attach file hidden
            $("#4").css('display','none');
            $("#5").css('display','none');
            $("#6").css('display','none');
            $("#7").css('display','none');
            $("#8").css('display','none');
            $("#9").css('display','none');
            $("#10").css('display','none');
            $("#12").css('display','none');
            $("#13").css('display','none');
            $("#14").css('display','none');
            $("#15").css('display','none');
            $("#16").css('display','none');
            $("#17").css('display','none');
            $("#18").css('display','none');
            $("#22").css('display','none');
            $("#24").css('display','none');
            $("#25").css('display','none');
            $("#26").css('display','none');
          }else if(this.value =='tooling_machine3'){//jika dipilih tooling machine 3 akan menonaktikan beberapa attach file
            $("#3").css('display','none');//beberapa attach file hidden
            $("#4").css('display','none');
            $("#5").css('display','none');
            $("#6").css('display','none');
            $("#7").css('display','none');
            $("#8").css('display','none');
            $("#9").css('display','none');
            $("#10").css('display','none');
            $("#12").css('display','none');
            $("#13").css('display','none');
            $("#14").css('display','none');
            $("#15").css('display','none');
            $("#16").css('display','none');
            $("#17").css('display','none');
            $("#18").css('display','none');
            $("#24").css('display','none');
            $("#25").css('display','none');
            $("#26").css('display','none');
          }else if(this.value =='tooling_machine4'){//jika dipilih tooling machine 4 akan menonaktikan beberapa attach file
            $("#3").css('display','none');//beberapa attach file hidden
            $("#4").css('display','none');
            $("#5").css('display','none');
            $("#6").css('display','none');
            $("#7").css('display','none');
            $("#8").css('display','none');
            $("#9").css('display','none');
            $("#10").css('display','none');
            $("#12").css('display','none');
            $("#13").css('display','none');
            $("#14").css('display','none');
            $("#15").css('display','none');
            $("#16").css('display','none');
            $("#17").css('display','none');
            $("#18").css('display','none');
            $("#22").css('display','none');
            $("#24").css('display','none');
            $("#25").css('display','none');
            $("#26").css('display','none');
          }else if(this.value =='tooling_machine5'){//jika dipilih tooling machine 5 akan menonaktikan beberapa attach file
            $("#3").css('display','none');//beberapa attach file hidden
            $("#4").css('display','none');
            $("#5").css('display','none');
            $("#6").css('display','none');
            $("#7").css('display','none');
            $("#8").css('display','none');
            $("#9").css('display','none');
            $("#10").css('display','none');
            $("#12").css('display','none');
            $("#13").css('display','none');
            $("#14").css('display','none');
            $("#15").css('display','none');
            $("#16").css('display','none');
            $("#17").css('display','none');
            $("#18").css('display','none');
            $("#22").css('display','none');
            $("#24").css('display','none');
            $("#25").css('display','none');
            $("#26").css('display','none');
          }else if(this.value =='tooling_machine6'){//jika dipilih tooling machine 6 akan menonaktikan beberapa attach file
            $("#3").css('display','none');//beberapa attach file hidden
            $("#4").css('display','none');
            $("#5").css('display','none');
            $("#6").css('display','none');
            $("#7").css('display','none');
            $("#8").css('display','none');
            $("#9").css('display','none');
            $("#10").css('display','none');
            $("#12").css('display','none');
            $("#13").css('display','none');
            $("#14").css('display','none');
            $("#15").css('display','none');
            $("#16").css('display','none');
            $("#17").css('display','none');
            $("#18").css('display','none');
            $("#22").css('display','none');
            $("#24").css('display','none');
            $("#25").css('display','none');
            $("#26").css('display','none');
          }else if(this.value =='tooling_machine7'){//jika dipilih tooling machine 7 akan menonaktikan beberapa attach file
            $("#3").css('display','none');//beberapa attach file hidden
            $("#4").css('display','none');
            $("#5").css('display','none');
            $("#6").css('display','none');
            $("#7").css('display','none');
            $("#8").css('display','none');
            $("#9").css('display','none');
            $("#10").css('display','none');
            $("#12").css('display','none');
            $("#13").css('display','none');
            $("#14").css('display','none');
            $("#15").css('display','none');
            $("#16").css('display','none');
            $("#17").css('display','none');
            $("#18").css('display','none');
            $("#22").css('display','none');
            $("#24").css('display','none');
            $("#25").css('display','none');
            $("#26").css('display','none');
          }else{
            $("#tooling_machine").removeAttr("checked");//untuk check apakah sudah hidden
            $("#tooling_machine2").css('display','block');//untuk blok attach file sudah dihidden
            }
          });





  }

</script>

<script type="text/javascript">

  ///@see get simpan data
     ///@note fungsi digunakan trigger simpan data
     ///@attention 
   function Simpan_data($trigger){

          // Form data
          var fdata = new FormData();
          
          // Form data collect name value
          var form_data = $('#quickForm').serializeArray();
          $.each(form_data, function (key, input) {
            fdata.append(input.name, input.value);
          });
          
          // Penanganan jika ada type check Box uncheck
          $('#quickForm input[type="checkbox"]:not(:checked)').each(function(i, e) {           
              fdata.append(e.getAttribute("name"),"Off");
          });

          // Penanganan jika ada type attach file
          $('#quickForm input[type="file"]').each(function(i, e) {     
              // jika ada file attach maka akan ditambahkan  
              if ($('#'+e.getAttribute("name")).val()) {   
                var file_data = $('#'+e.getAttribute("name")).prop('files')[0];
                fdata.append(e.getAttribute("name"),file_data);                            
              }
          });

          // Print_r(file_data);

          // Simpan or Update data          
          var vurl; 
          if($trigger == 'Add') {            
            vurl = "<?php echo base_url('C_PCN/ajax_add')?>";//link simpan data
          } else {           
            vurl = "<?php echo base_url('C_PCN/ajax_update')?>";//link update data
          }
        
          //untuk aja data sudah bisa dipost
          $.ajax({
              url: vurl,//url
              method: "post",//jenis method pst
              processData: false,//false process
              contentType: false,//false content
              data: fdata,
              success: function (data) {
                 
                   // Pesan berhasil
                   berhasil(data.status);
                   // Reset Form
                   $('#quickForm')[0].reset();               
                   // location.reload();
                    tabel.draw();
                  //location add
                   if(!vurl=="Add"){
                     $("#modal-default").modal('hide');
                   }

                   $("#modal-default").modal('hide');
                 
              },
              // function error
              error: function (e) {
                  gagal(e);
                  //location.reload();
                  //error
              }
          });

  }

   ///@see get send email
     ///@note fungsi digunakan mengirim data ke email
     ///@attention 
  function ajax_send_mail(){

// Form data
var fdata = new FormData();//variable untuk send mail
print_r(fdata); //untuk fungsi print

// Form data collect name value
var form_data = $('#quickForm').serializeArray();//variable form data
$.each(form_data, function (key, input) { //function untuk rule send email
  fdata.append(input.name, input.value);
});

// Penanganan jika ada type check Box uncheck
$('#quickForm input[type="checkbox"]:not(:checked)').each(function(i, e) {           
    fdata.append(e.getAttribute("name"),"Off");
});

// Simpan or Update data          
var vurl;  //url
vurl = "<?php echo base_url('C_Email/ajax_send_mail_v1')?>"; //link send email

$.ajax({ //ajax pada send email
    url: vurl, //url
    method: "post",//jenis method pst
    processData: false,//false process
    contentType: false,//false content
    data: fdata,
    success: function (data) {                 
        // Pesan berhasil
        berhasil(data.status);                               
    },
    error: function (e) {
        gagal(e);
        //location.reload();
        //error
    }
});

}

///@see get send draft
///@note fungsi digunakan mengirim data menjadi draft
///@attention 
function sendDraft(){

// Form data
var fdata = new FormData(); //variable untuk sendraft
fdata.append("hdrid",$('#hdrid').val()); //fungsi send draft dengan hdrid
fdata.append("nik",$('#nik').val());   //fungsi send draft dengan nik
var fdata2 = new FormData(); //variable untuk form data

fdata2.append("body_content","");  //fungsi body content
fdata2.append("comment","");  //fungsi comment
fdata2.append("status_subject","New");  //fungsi status subject

// Data 2
var form_data = $('#quickForm').serializeArray(); // variable quick form
$.each(form_data, function (key, input) { //function untuk rule senddraft
    fdata2.append(input.name, input.value);
}); 

// Penanganan jika ada type check Box uncheck
$('#quickForm input[type="checkbox"]:not(:checked)').each(function(i, e) {
fdata.append(e.getAttribute("name"), "Off");
});

// Penanganan jika ada type attach file
$('#quickForm input[type="file"]').each(function(i, e) {

// jika ada file attach maka akan ditambahkan  
if ($('#' + e.getAttribute("name")).val()) {
var file_data = $('#' + e.getAttribute("name")).prop('files')[0];
fdata.append(e.getAttribute("name"), file_data);
}
});

// Simpan or Update data          
var vurl; 
vurl = "<?php echo base_url('C_PCN/ajax_sendDraft')?>";//link senddraft

$.ajax({ //ajax pada send draft
    url: vurl, //url
    method: "post",//jenis method pst
    processData: false,//false process
    contentType: false,//false content
data: fdata,
success: function (data) {

        fdata2.append("hdrid",data.status);  //status sukses di hdrid
        fdata2.append("problem_name",$('#problem_name').val()); //status sukses di problem name
        fdata2.append("group_product_name",$('#group_product_name').val()); //status sukses di group_product_name
        fdata2.append("product_name",$('#product_name').val());  //status sukses di product_name
        fdata2.append("name2",$('#name2').val()); //status sukses di name2
        fdata2.append("problem_category_name",$('#problem_category_name').val()); //status sukses di problem_category_name
        fdata2.append("body_content",data.status_transaction); //status sukses di body_content
        fdata2.append("comment",""); //status group comment
        fdata2.append("status_subject","");//status group status_subject
        fdata2.append('position_code', "2");//status group position_code

      var vurl2; 
      vurl2 = "<?php echo base_url('C_Email/ajax_send_mail_v2')?>";//link send mail v2

      $.ajax({
          url: vurl2,
          method: "post", //jenis method pst
          processData: false,//false process
          contentType: false,//false content
          data: fdata2,
          success: function (data) {                 
             
          },
          error: function (e) {
              gagal(e);
             
          }
      });

      berhasil("Berhasil dikirim");   //jika sudah dikirim ke email maka akan muncul notif "berhasil dikirim"
      tabel.draw();
      $("#modal-default").modal('hide');

  
},
error: function (e) {
    gagal(e);
    //location.reload();
    //error
}
});

}



///@see get send draft
///@note fungsi digunakan mengirim data menjadi draft
///@attention 
function sendDraft2() { //variable untuk sendraft2

    // Form data
    var fdata = new FormData();//variable untuk sendraft

    var fdata2 = new FormData();             
    fdata2.append("body_content",""); //fungsi body content
    fdata2.append("comment",""); //fungsi comment
    fdata2.append("status_subject","New");//fungsi status subject

    // Form data collect name value
    var form_data = $('#quickForm').serializeArray();// variable quick form
    $.each(form_data, function(key, input) { //function untuk rule senddraft
      fdata.append(input.name, input.value);
    });

    $.each(form_data, function(key, input) {
      fdata2.append(input.name, input.value);
    });

    // Penanganan jika ada type check Box uncheck
    $('#quickForm input[type="checkbox"]:not(:checked)').each(function(i, e) {
      fdata.append(e.getAttribute("name"), "Off");
    });

    // Penanganan jika ada type attach file
    $('#quickForm input[type="file"]').each(function(i, e) {
      // jika ada file attach maka akan ditambahkan  
      if ($('#' + e.getAttribute("name")).val()) {
        var file_data = $('#' + e.getAttribute("name")).prop('files')[0];
        fdata.append(e.getAttribute("name"), file_data);
      }
    });

    // Print_r(file_data); 
    // Pesan berhasil
    
    // Simpan or Update data          
    var vurl;
    vurl = "<?php echo base_url('C_PCN/ajax_sendDraft2') ?>"; //link senddraft2

    $.ajax({ //ajax pada send draft
      url: vurl, //url
      method: "post", //jenis method pst
      processData: false,//false process
      contentType: false,//false content
      data: fdata,
      success: function(data) {

        // gagal("hello" + data.status);
        // print_r(data.status);
        
        fdata2.append("hdrid",data.status); 
        fdata2.append("problem_name",$('#problem_name').val());  //status sukses di hdrid
        fdata2.append("group_product_name",$('#group_product_name').val()); //status sukses di problem name
        fdata2.append("product_name",$('#product_name').val()); //status sukses di group_product_name
        fdata2.append("name2",$('#name2').val()); //status sukses di product_name
        fdata2.append("problem_category_name",$('#problem_category_name').val()); //status sukses di name2
        fdata2.append("body_content",data.status_transaction); //status sukses di problem_category_name
        fdata2.append("comment",""); //status group comment
        fdata2.append("status_subject","");//status_subject
        fdata2.append('position_code', "2");//status group position_code

        // Kirim email
        var vurl2; 
        vurl2 = "<?php echo base_url('C_Email/ajax_send_mail_v2')?>";//link send mail v2
          $.ajax({
          url: vurl2, //url
          method: "post",//jenis method pst
          processData: false,//false process
          contentType: false,//false content
          data: fdata2,
          success: function (data) {                
                                                   
          },
          error: function (e) {
              gagal(e);
             
          }
        });


        berhasil(data.status);    //jika berhasil maka akan muncul notif "berhasil dikirim"
        tabel.draw();
        $("#modal-default").modal('hide');


      },
      error: function(e) {
        gagal(e);
        //location.reload();
        //error
      }
    });

}



///@see get delete data
///@note fungsi digunakan untuk delete data
///@attention 
function Delete_data(){

// Form data
var fdata = new FormData();

// Delete by Hdrid
fdata.append('hdrid',$('#iddelete').text());
// Url Post delete
vurl = "<?php echo base_url('C_PCN/ajax_delete')?>";//link untuk delete

// Post data
$.ajax({//ajax delete
url: vurl,//url
method: "post",//jenis method pst
processData: false,//false process
contentType: false,//false content
data: fdata,
success: function (data) {

    // Hide modal delete
    $('#modal-delete').modal('hide');
    // Delete rows datatables
    $('#example1').DataTable().row("#"+$('#iddelete2').text()).remove().draw();
    // Pesan berhasil
    berhasil(data.status);   

},
error: function (e) {
    //Pesan Gagal
    gagal(e);             
}
});

}
// ///@see get send mail
// ///@note fungsi digunakan untuk mengirim email
// ///@attention 
// function Send_mail(){

//   // Url Post delete
//   vurl = "<?php echo base_url('C_Email/Send_mail')?>";//link untuk send mail
//   // Form data
//   var fdata = new FormData();
//   fdata.append('hdrid','Hdrid123');


//   $.ajax({//ajax send mail
//         url: vurl,//url
//         method: "post",//jenis method pst
//         processData: false,//false process
//         contentType: false,//false content
//       data: fdata,
//       success: function (data) {
//       },
//       error: function (e) {
//           //Pesan Gagal
//           //gagal(e);             
//       }
//   });

// }


</script>

<!-- ***************************** Handle Button di datatable (View,edit,delete,row selected) ***************************** -->
<script type="text/javascript">

    //  HDRID selected konfirmasiHapus
    $(document).on("click", ".konfirmasiHapus", function() {        
        $('#iddelete').text($(this).attr("data-id")); 
    })

    //  HDRID selected  konfirmasiEdit
    $(document).on("click", ".konfirmasiEdit", function() {     
      view_modal($(this).attr("data-id"),'Edit');
    })
     
    //  HDRID selected  konfirmasiEdit
    $(document).on("click", ".konfirmasiView", function() {   
      view_modal($(this).attr("data-id"),'View');
    })

    // ID Rows selected
    $('#example1').on( 'click', 'tr', function () {
          $('#iddelete2').text($('#example1').DataTable().row( this ).id());             
    } );

</script>


<script type="text/javascript">

   $('.select2').select2();

    //Date range picker
    $('#reservationdate').datetimepicker({
            format: 'L'           
    });

    
    //Date range picker
    $('#startdate').datetimepicker({
            format: 'L'           
    });

    //Date range picker
    $('#enddate').datetimepicker({
            format: 'L'           
    });

</script>

<!-- <script type="text/javascript">
  document.getElementById('btnsubmit2').onclick = function() {
    var select = document.getElementById('multiple');
    var selected = [...select.options]
                      .filter(option => option.selected)
                      .map(option => option.value);
    alert(selected);
  } 
</script> -->

<!-- Handle datatable -->
<script type="text/javascript">

    var tabel = null;
    $(document).ready(function() {

        tabel = $('#example1').DataTable({//table
            "processing": true,//processing true jika data masuk table
            "responsive":true,//respon jika data masuk akan muncul pop up data
            "serverSide": true, //untuk data masuk server 
            "ordering": true, // Set true agar bisa di sorting
            "order": [[ 0, 'asc' ]], // Default sortingnya berdasarkan kolom / field ke 0 (paling pertama)
            dom: "lfBrtip",
            buttons: [
            {
              extend: 'copyHtml5',//extend html
              className: 'btn btn-secondary',//button
              text: '<i class="fas fa-copy">&nbsp</i> Copy Data to Clipboard',//untuk copy cliboard
            },
            {
              extend: 'csvHtml5',//extend html
              className: 'btn btn-info',//button
              text: '<i class="fas fa-file-csv">&nbsp</i> Export Data to CSV',//untuk export data ke csv
            },
            {
              extend: 'excelHtml5',//extend html
              className: 'btn btn-success',//button
              text: '<i class="fas fa-file-excel">&nbsp</i> Export Data to Excel',//untuk export data ke excel
              customize: function ( xlsx ){//type data excel
                var sheet = xlsx.xl.worksheets['sheet1.xml'];
                // jQuery selector to add a border
                $( 'row c', sheet ).attr( 's', '25' );
              }
            },
            {
              extend : 'pdfHtml5',   //extend html             
              className: 'btn btn-danger',  //button
              text: '<i class="fas fa-file-pdf">&nbsp</i> Export Data to PDF', //untuk export data ke pdf
              orientation : 'landscape', //type landscape
              pageSize : 'A4', //ukuran kertas
              download: 'open' //download 
            }
          ],
            "ajax":
            {
                "url": "<?= base_url('C_PCN/view_data_where');?>", // URL file untuk proses select datanya
                "type": "POST", //post select datanya
                "data": function(data){     
                  data.searchByFromdate = $('#search_fromdate').val(); //value from date
                  data.searchByTodate = $('#search_todate').val(); //value to date
                }

            },
            "deferRender": true,
            "aLengthMenu": [[5, 10,100,1000,10000,100000,1000000,1000000000],[ 5, 10, 100,1000,10000,100000,1000000,"All"]], // Combobox Limit
            "columns": [
               {"data": 'hdrid',"sortable": false, //1
                    render: function (data, type, row, meta) {
                        // return meta.row + meta.settings._iDisplayStart + 1;
                        // return '<div class="btn btn-success btn-sm konfirmasiView" data-id="'+ data +'" data-toggle="modal" data-target="#modal-default" > <i class="fa fa-eye"></i></div> <div class="btn btn-danger btn-sm konfirmasiHapus" data-id="'+ data +'" data-toggle="modal" data-target="#modal-delete" > <i class="fa fa-trash"></i></div> <div class="btn btn-primary btn-sm konfirmasiEdit" data-id="'+ data +'" data-toggle="modal" data-target="#modal-default"> <i class="fa fa-edit"></i></div>';
                        mnu='';
                        mnu=mnu+'<div class="btn btn-success btn-sm konfirmasiView mr-2" data-id="'+ data +'" data-toggle="modal" data-target="#modal-default" > <i class="fa fa-eye"></i></div>';
                        mnu=mnu+'<div class="btn btn-primary btn-sm konfirmasiEdit mr-2" data-id="'+ data +'" data-toggle="modal" data-target="#modal-default"> <i class="fa fa-edit"></i></div>'; mnu=mnu + '<div class="btn btn-danger btn-sm konfirmasiHapus" data-id="'+ data +'" data-toggle="modal" data-target="#modal-delete" > <i class="fa fa-trash"></i></div>';
                        mnu = mnu + '<a class="btn btn-secondary btn-sm mr-2"  href="<?php echo base_url('C_Print_approved/print_report2_approved?var1=') . "'+ data +' &var2=1&var2=1"  ?>"  target="_blank"> <i class="fas fa-print mr-1"></i>A4</a>'
                        
                        return mnu;

                    }  
                },
                
                // ---------------------------------- Datatables Macro Batas sini ---------------------------------
                {"data":"hdrid"},
                {"data":"email"},
                {"data":"transaction_date"},
                {"data":"supplier_name"},
                {"data":"prepared"},
                {"data":"checked"},
                {"data":"approved"},
                {"data":"any_cost_impact"},
                {"data":"cost_impact"},
                {"data":"capacity_impact"},
                {"data":"before_capacity"},
                {"data":"after_capacity"},
                {"data":"part_number"},
                {"data":"part_name"},
                {"data":"product_name"},
                {"data":"object_type"},
                {"data":"reason_to_change"},
                {"data":"description_of_process_change"},
                {"data":"current_process"},
                {"data":"proposed_process"},
                {"data":"characteristics_affected"},
                {"data":"criteria_critical_item"},
                {"data":"trial_manufacturing"},
                {"data":"trial_manufacturing_completed_finish"},
                {"data":"process_capability_study"},
                {"data":"process_capability_study_completed_finish"},
                {"data":"initial_sample_inspection_completed"},
                {"data":"initial_sample_inspection_completed_finish"},
                {"data":"initial_sample_submission"},
                {"data":"initial_sample_submission_finish"},
                {"data":"timing_denso_approval"},
                {"data":"timing_denso_approval_finish"},
                {"data":"m_or_p_starts"},
                {"data":"mass_production_starts_finish"},
                {"data":"m_or_p_shipment"},
                {"data":"mass_production_shipment_finish"},
                {"data":"entry_example_start"},
                {"data":"entry_example_finish"},
                {"data":"folder"},
                {"data":"stat"},

      


                // ---------------------------------- / Datatables Macro Batas sini --------------------------------

            ],


        });

        // Search button
        $('#search').click(function(){

          
            if($('#search_fromdate').val() != '' && $('#search_todate').val() !='')
            {
                tabel.draw();
            }
            else
            {
              gagal("Both Date is Required");
            }

        });


    });
    
</script>


<script type="text/javascript">

     ///@see get vreadonly
     ///@note fungsi jika hanya user bisa melihat data tanpa diedit dan hanya administrator bisa edit
     ///@attention 
    function vreadonly(form,vboolean){
    
      // alert(form);

      // var x = $(form).serializeArray();

      // $.each(x, function(i, field){

      //   if(field.name=="hdrid"){
      //     if(vboolean==true){
      //       document.getElementsByName(field.name)[0].readOnly=true;
      //     }else{
      //       document.getElementsByName(field.name)[0].readOnly=false;
      //     }
      //   }
        
      // });".form_datetime" // '#timepickerreport_date'

     
    }


</script>

<script type="text/javascript">
  $(document).ready(function () {
    bsCustomFileInput.init();
  });
</script>


<script type="text/javascript">

    ///@see handleSelectChange_supplier_name()
     ///@note fungsi untuk filter data
     ///@attention jika type filter tidak sesuai field maka filter tersebut tidak aktif
  function handleSelectChange_supplier_name(event) {
 
    var data = $('#supplier_name').select2('data')[0].text;
    
    if (data=='-Select-'){
      $('#prepared').val('');   
      $('#check').val('');   
      $('#approved').val('');   
      $('#part_number').val('');   
      $('#part_name').val('');   
      $('#product_name').val('');    
      $('#reason').val('');  

    }else{
      var res = data.split("-");
      $('#prepared').val(res[1]);
      $('#check').val(res[2]);
      $('#approved').val(res[3]);
      $('#part_number').val(res[4]);
      $('#part_name').val(res[5]);
      $('#product_name').val(res[6]);
      $('#reason').val(res[7]);

    };

  }

      ///@see handleSelectChange_any_cost_impact()
     ///@note fungsi untuk filter data
     ///@attention jika type filter tidak sesuai field maka filter tersebut tidak aktif
  function handleSelectChange_any_cost_impact(event) {

var data = $('#any_cost_impact').select2('data')[0].text;
 
if (data=='-Select-'){
   $('#cost_impact').val('');   
 }else{
   var res = data.split("-");
   $('#cost_impact').val(res[1]);
 };

}

    ///@see handleSelectChange_capacity_impact()
     ///@note fungsi untuk filter data
     ///@attention jika type filter tidak sesuai field maka filter tersebut tidak aktif
function handleSelectChange_capacity_impact(event) {
 
 var data = $('#capacity_impact').select2('data')[0].text;
 
 if (data=='-Select-'){
   $('#before_capacity').val('');   
   $('#after_capacity').val('');   
 }else{
   var res = data.split("-");
   $('#before_capacity').val(res[1]);
   $('#after_capacity').val(res[2]);
 };

}

    ///@see handleSelectChange_description_of_process_change()
     ///@note fungsi untuk filter data
     ///@attention jika type filter tidak sesuai field maka filter tersebut tidak aktif
     function handleSelectChange_description_of_process_change(event) {
 
 var data = $('#description_of_process_change').select2('data')[0].text;
 
 if (data=='-Select-'){
   $('#current_process').val('');   
   $('#proposed_process').val('');   
   $('#characteristics_affected').val(''); 
   $('#trial_manufacturing_completed_start').val('');  
   $('#trial_manufacturing_completed_finish').val('');  
   $('#initial_sample_inpection_completed_start').val('');  
   $('#initial_sample_inpection_completed_finish').val('');  
   $('#initial_sample_submission_start').val('');  
   $('#initial_sample_submission_finish').val('');  
   $('#timing_denso_approval_start').val('');  
   $('#timing_denso_approval_finish').val('');  
   $('#mass_productin_starts_start').val(''); 
   $('#mass_productin_starts_finish').val(''); 
   $('#entry_example_start').val(''); 
   $('#entry_example_finish').val(''); 


 }else{
   var res = data.split("-");
   $('#current_process').val(res[1]);
   $('#proposed_process').val(res[2]);
   $('#characteristics_affected').val(res[3]);
   $('#trial_manufacturing_completed_start').val(res[4]);
   $('#trial_manufacturing_completed_finish').val(res[5]);
   $('#initial_sample_inpection_completed_start').val(res[6]);
   $('#initial_sample_inpection_completed_finish').val(res[7]);
   $('#initial_sample_submission_start').val(res[8]);
   $('#initial_sample_submission_finish').val(res[9]);
   $('#timing_denso_approval_start').val(res[10]);
   $('#timing_denso_approval_finish').val(res[11]);
   $('#mass_productin_starts_start').val(res[12]);
   $('#mass_productin_starts_finish').val(res[13]);
   $('#entry_example_start').val(res[14]);
   $('#entry_example_finish').val(res[15]);
   
 };

}

      ///@see handleSelectChange_email()
     ///@note fungsi untuk filter data
     ///@attention jika type filter tidak sesuai field maka filter tersebut tidak aktif
     function handleSelectChange_email(event) {

var data = $('#email').select2('data')[0].text;
 
if (data=='-Select-'){
   $('#stat').val('');   
 }else{
   var res = data.split("-");
   $('#stat').val(res[1]);
 };

}


   ///@see handleSelectChange_group_product_id()
     ///@note fungsi untuk filter data
     ///@attention jika type filter tidak sesuai field maka filter tersebut tidak aktif
  function handleSelectChange_group_product_id(event) {

    var data = $('#group_product_id').select2('data')[0].text;
    
    if (data=='-Select-'){
      $('#group_product_name').val('');   
    }else{
      var res = data.split("-");
      $('#group_product_name').val(res[1]);
    };

  }

   ///@see handleSelectChange_product_id()
     ///@note fungsi untuk filter data
     ///@attention jika type filter tidak sesuai field maka filter tersebut tidak aktif
  function handleSelectChange_product_id(event) {

    var data = $('#product_id').select2('data')[0].text;

    if (data=='-Select-'){
      $('#product_name').val('');   
    }else{
      var res = data.split("-");
      $('#product_name').val(res[1]);
      // $('#report_no').val(res[2]);
    };

  }

     ///@see handleSelectChange_customer_id()
     ///@note fungsi untuk filter data
     ///@attention jika type filter tidak sesuai field maka filter tersebut tidak aktif
  function handleSelectChange_customer_id(event) {

    var data = $('#customer_id').select2('data')[0].text;

    if (data=='-Select-'){
      $('#customer_name').val('');   
    }else{
      var res = data.split("-");
      $('#customer_name').val(res[1]);
    };

  }

     ///@see handleSelectChange_source_information_id()
     ///@note fungsi untuk filter data
     ///@attention jika type filter tidak sesuai field maka filter tersebut tidak aktif
  function handleSelectChange_source_information_id(event) {

    var data = $('#source_information_id').select2('data')[0].text;

    if (data=='-Select-'){
      $('#source_information_name').val('');   
    }else{
      var res = data.split("-");
      $('#source_information_name').val(res[1]);
    };

  }


     ///@see handleSelectChange_nik()
     ///@note fungsi untuk filter data
     ///@attention jika type filter tidak sesuai field maka filter tersebut tidak aktif
  function handleSelectChange_nik(event) {

  var data = $('#nik').select2('data')[0].text;

  if (data=='-Select-'){
    $('#name').val('');   
    $('#section1').val('');    
    $('#email1').val('');    
  }else{
    var res = data.split("-");
    $('#name').val(res[1]);
    $('#section1').val(res[2]);
    $('#email1').val(res[3]);
  };

}

   ///@see handleSelectChange_nik2()
     ///@note fungsi untuk filter data
     ///@attention jika type filter tidak sesuai field maka filter tersebut tidak aktif
  function handleSelectChange_nik2(event) {

  var data = $('#nik2').select2('data')[0].text;

  if (data=='-Select-'){
    $('#name2').val('');   
    $('#section2').val('');   
    $('#email2').val('');   
  }else{
    var res = data.split("-");
    $('#name2').val(res[1]);
    $('#section2').val(res[2]);
    $('#email2').val(res[3]);
  };

}

   ///@see handleSelectChange_rank_problem()
     ///@note fungsi untuk filter data
     ///@attention jika type filter tidak sesuai field maka filter tersebut tidak aktif
  function handleSelectChange_rank_problem(event) {

  var data = $('#nik2').select2('data')[0].text;



}

   ///@see handleSelectChange_temporary_action()
     ///@note fungsi untuk filter data
     ///@attention jika type filter tidak sesuai field maka filter tersebut tidak aktif
  function handleSelectChange_temporary_action(event) {

  var data = $('#temporary_action').select2('data')[0].text;

}


</script>

<script type="text/javascript">

          // Setting min max Report
          $(function () {
            
            var someDate2 = new Date();            
            var result0 = someDate2.setDate(someDate2.getDate() + 0);
            var result2 = someDate2.setDate(someDate2.getDate() + 14);
         
             $('#timepickerreport_date').datetimepicker(
               {
                minDate: new Date(result0).toISOString().slice(0, 10),
                maxDate: new Date(result2).toISOString().slice(0, 10)
               }
             );

         });s

</script>


<script type="text/javascript">

function test(event) {

// var data = $('#temporary_action').select2('data')[0].text;
// alert('berhasil');
// document.getElementById('requirement_document').style.display ='block';
// document.getElementById('requirement_document_1').style.display ='none';

}

  </script>









